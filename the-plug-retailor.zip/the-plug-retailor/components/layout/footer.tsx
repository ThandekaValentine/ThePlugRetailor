import Link from 'next/link'
import { Facebook, Instagram, Twitter } from 'lucide-react'

const footerLinks = {
  Shop: [
    { label: 'New Products', href: '/shop/new' },
    { label: 'Preloved Products', href: '/shop/preloved' },
    { label: 'All Brands', href: '/about#brands' },
    { label: 'Special Offers', href: '/shop/new?sale=true' },
  ],
  Account: [
    { label: 'My Profile', href: '/account/profile' },
    { label: 'My Orders', href: '/account/orders' },
    { label: 'Wishlist', href: '/account/wishlist' },
    { label: 'Track My Order', href: '/track' },
  ],
  Support: [
    { label: 'Contact Us', href: '/contact' },
    { label: 'FAQ', href: '/faq' },
    { label: 'Returns & Refunds', href: '/returns' },
    { label: 'Shipping Info', href: '/faq#shipping' },
  ],
  Legal: [
    { label: 'Terms & Conditions', href: '/terms' },
    { label: 'Privacy Policy', href: '/privacy' },
    { label: 'POPIA Compliance', href: '/privacy#popia' },
    { label: 'Cookie Policy', href: '/privacy#cookies' },
  ],
}

export default function Footer() {
  return (
    <footer className="bg-foreground text-background mt-20">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand col */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="h-8 w-8 rounded-sm bg-brand-green flex items-center justify-center">
                <span className="text-white font-bold text-sm">P</span>
              </div>
              <span className="font-bold text-lg">The Plug Retailor</span>
            </div>
            <p className="text-sm opacity-70 mb-6 leading-relaxed">
              Your Home for South African Brands. Supporting local, celebrating heritage, one purchase at a time.
            </p>
            {/* SA Flag accent */}
            <div className="flex gap-1 mb-6">
              <div className="h-1 flex-1 bg-brand-green rounded-full" />
              <div className="h-1 flex-1 bg-brand-gold rounded-full" />
              <div className="h-1 flex-1 bg-brand-red rounded-full" />
            </div>
            <div className="flex gap-3">
              <a href="#" className="opacity-70 hover:opacity-100 transition-opacity" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="opacity-70 hover:opacity-100 transition-opacity" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="opacity-70 hover:opacity-100 transition-opacity" aria-label="X / Twitter">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="opacity-70 hover:opacity-100 transition-opacity text-sm font-bold" aria-label="TikTok">
                TT
              </a>
            </div>
          </div>

          {/* Link cols */}
          {Object.entries(footerLinks).map(([section, links]) => (
            <div key={section}>
              <h4 className="text-sm font-semibold uppercase tracking-wider mb-4 opacity-50">
                {section}
              </h4>
              <ul className="space-y-2.5">
                {links.map(link => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm opacity-70 hover:opacity-100 transition-opacity"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm opacity-50">
            © {new Date().getFullYear()} The Plug Retailor. All rights reserved. Proudly South African 🇿🇦
          </p>
          <div className="flex items-center gap-4 text-sm opacity-50">
            <span>PayFast</span>
            <span>Ozow</span>
            <span>EFT</span>
            <span>Visa</span>
            <span>Mastercard</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
