'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import {
  Search,
  ShoppingBag,
  Heart,
  Menu,
  X,
  Sun,
  Moon,
  User,
  ChevronDown,
} from 'lucide-react'
import { useTheme } from 'next-themes'
import { useCartStore } from '@/lib/store'
import { CATEGORIES } from '@/lib/utils'
import { cn } from '@/lib/utils'

const navLinks = [
  { label: 'New Products', href: '/shop/new' },
  { label: 'Preloved', href: '/shop/preloved' },
  { label: 'Brands', href: '/about#brands' },
  { label: 'About', href: '/about' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [shopOpen, setShopOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const totalItems = useCartStore(s => s.getTotalItems())

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full transition-all duration-200',
        scrolled
          ? 'bg-background/95 backdrop-blur-sm border-b shadow-sm'
          : 'bg-background border-b'
      )}
    >
      {/* Top bar */}
      <div className="bg-brand-green text-white text-xs text-center py-1.5 px-4">
        🇿🇦 Free delivery on orders over R750 — Proudly supporting South African brands
      </div>

      {/* Main nav */}
      <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-sm bg-brand-green flex items-center justify-center">
              <span className="text-white font-bold text-sm">P</span>
            </div>
            <div className="hidden sm:block">
              <span className="font-bold text-lg tracking-tight">The Plug</span>
              <span className="text-brand-green font-bold text-lg tracking-tight ml-1">Retailor</span>
            </div>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6">
          <div className="relative group">
            <button
              className="flex items-center gap-1 text-sm font-medium hover:text-brand-green transition-colors"
              onMouseEnter={() => setShopOpen(true)}
              onMouseLeave={() => setShopOpen(false)}
            >
              Shop
              <ChevronDown className="h-3.5 w-3.5" />
            </button>
            {shopOpen && (
              <div
                className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-64 bg-background rounded-xl border shadow-lg p-4 z-50"
                onMouseEnter={() => setShopOpen(true)}
                onMouseLeave={() => setShopOpen(false)}
              >
                <Link
                  href="/shop/new"
                  className="block px-3 py-2 rounded-lg hover:bg-muted text-sm font-medium"
                >
                  🆕 New Products
                </Link>
                <Link
                  href="/shop/preloved"
                  className="block px-3 py-2 rounded-lg hover:bg-muted text-sm font-medium"
                >
                  ♻️ Preloved Products
                </Link>
                <div className="my-2 border-t" />
                <p className="px-3 text-xs text-muted-foreground uppercase tracking-wider mb-1">
                  Categories
                </p>
                {CATEGORIES.slice(0, 6).map(cat => (
                  <Link
                    key={cat.id}
                    href={`/shop/new?category=${cat.id}`}
                    className="block px-3 py-1.5 rounded-lg hover:bg-muted text-sm"
                  >
                    {cat.emoji} {cat.label}
                  </Link>
                ))}
              </div>
            )}
          </div>
          {navLinks.slice(1).map(link => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium hover:text-brand-green transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-1">
          <Link
            href="/shop/new"
            className="hidden md:flex items-center gap-1.5 p-2 rounded-lg hover:bg-muted transition-colors"
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </Link>
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-2 rounded-lg hover:bg-muted transition-colors"
            aria-label="Toggle theme"
          >
            <Sun className="h-5 w-5 dark:hidden" />
            <Moon className="h-5 w-5 hidden dark:block" />
          </button>
          <Link
            href="/account/wishlist"
            className="p-2 rounded-lg hover:bg-muted transition-colors"
            aria-label="Wishlist"
          >
            <Heart className="h-5 w-5" />
          </Link>
          <Link
            href="/account/profile"
            className="hidden sm:flex p-2 rounded-lg hover:bg-muted transition-colors"
            aria-label="Account"
          >
            <User className="h-5 w-5" />
          </Link>
          <Link
            href="/cart"
            className="relative p-2 rounded-lg hover:bg-muted transition-colors"
            aria-label="Cart"
          >
            <ShoppingBag className="h-5 w-5" />
            {totalItems > 0 && (
              <span className="absolute -top-0.5 -right-0.5 h-4.5 w-4.5 min-w-[18px] rounded-full bg-brand-green text-white text-[10px] font-bold flex items-center justify-center px-1">
                {totalItems > 9 ? '9+' : totalItems}
              </span>
            )}
          </Link>
          <button
            className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
            onClick={() => setOpen(!open)}
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t bg-background">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-1">
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-3 rounded-lg hover:bg-muted text-sm font-medium"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="border-t my-2" />
            <p className="px-4 text-xs text-muted-foreground uppercase tracking-wider">
              Categories
            </p>
            {CATEGORIES.map(cat => (
              <Link
                key={cat.id}
                href={`/shop/new?category=${cat.id}`}
                className="px-4 py-2 rounded-lg hover:bg-muted text-sm"
                onClick={() => setOpen(false)}
              >
                {cat.emoji} {cat.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  )
}
