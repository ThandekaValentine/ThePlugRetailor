'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Heart, ShoppingBag, Star } from 'lucide-react'
import { Product } from '@/types'
import { cn, formatPrice, getConditionLabel, getConditionColor, calculateDiscount } from '@/lib/utils'
import { useCartStore, useWishlistStore } from '@/lib/store'
import { Badge } from '@/components/ui/badge'

interface ProductCardProps {
  product: Product
  className?: string
}

export default function ProductCard({ product, className }: ProductCardProps) {
  const { addItem } = useCartStore()
  const { toggle, isWishlisted } = useWishlistStore()
  const wishlisted = isWishlisted(product.id)

  const defaultSize = product.sizes[0]
  const discount = product.originalPrice
    ? calculateDiscount(product.originalPrice, product.price)
    : null

  return (
    <div
      className={cn(
        'group relative bg-card rounded-2xl overflow-hidden border hover:border-brand-green/30 hover:shadow-md transition-all duration-200',
        className
      )}
    >
      {/* Image */}
      <Link href={`/shop/product/${product.id}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden bg-muted">
          <Image
            src={product.images[0]}
            alt={product.name}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-300"
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          />
          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.type === 'preloved' && (
              <Badge className={cn('text-[10px] px-2', getConditionColor(product.condition))}>
                {getConditionLabel(product.condition)}
              </Badge>
            )}
            {discount && (
              <Badge variant="destructive" className="text-[10px] px-2">
                -{discount}%
              </Badge>
            )}
            {product.stock <= 5 && product.stock > 0 && (
              <Badge variant="gold" className="text-[10px] px-2">
                Only {product.stock} left
              </Badge>
            )}
          </div>

          {/* Wishlist btn */}
          <button
            onClick={e => {
              e.preventDefault()
              toggle(product)
            }}
            className={cn(
              'absolute top-3 right-3 h-8 w-8 rounded-full flex items-center justify-center transition-all',
              wishlisted
                ? 'bg-red-50 text-red-500'
                : 'bg-white/80 backdrop-blur-sm text-muted-foreground hover:text-red-500 opacity-0 group-hover:opacity-100'
            )}
            aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          >
            <Heart className={cn('h-4 w-4', wishlisted && 'fill-current')} />
          </button>
        </div>
      </Link>

      {/* Info */}
      <div className="p-4">
        <Link href={`/shop/product/${product.id}`}>
          <p className="text-xs text-muted-foreground mb-0.5 font-medium uppercase tracking-wide">
            {product.brand}
          </p>
          <h3 className="font-semibold text-sm leading-tight mb-2 hover:text-brand-green transition-colors line-clamp-2">
            {product.name}
          </h3>
        </Link>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={cn(
                  'h-3 w-3',
                  i < Math.floor(product.rating)
                    ? 'text-brand-gold fill-brand-gold'
                    : 'text-muted-foreground'
                )}
              />
            ))}
          </div>
          <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
        </div>

        {/* Price + CTA */}
        <div className="flex items-center justify-between gap-2">
          <div>
            <span className="font-bold text-base">{formatPrice(product.price)}</span>
            {product.originalPrice && (
              <span className="text-xs text-muted-foreground line-through ml-1.5">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>
          <button
            onClick={() => addItem(product, defaultSize)}
            disabled={product.stock === 0}
            className="flex items-center gap-1.5 bg-brand-green text-white text-xs font-semibold px-3 py-2 rounded-lg hover:bg-[#006640] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Add to cart"
          >
            <ShoppingBag className="h-3.5 w-3.5" />
            Add
          </button>
        </div>
      </div>
    </div>
  )
}
