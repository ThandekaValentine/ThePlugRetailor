'use client'

import { useState } from 'react'
import { Search, SlidersHorizontal, X } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { CATEGORIES, PRELOVED_CONDITIONS, cn } from '@/lib/utils'
import { FilterState, ProductCategory } from '@/types'
import { mockBrands } from '@/mock-data/brands'

interface ProductFiltersProps {
  filters: FilterState
  onChange: (filters: FilterState) => void
  showCondition?: boolean
}

export default function ProductFilters({ filters, onChange, showCondition }: ProductFiltersProps) {
  const [open, setOpen] = useState(false)

  const update = (partial: Partial<FilterState>) => onChange({ ...filters, ...partial })

  const hasActiveFilters =
    filters.category || filters.brand || filters.condition || filters.search ||
    filters.priceRange[0] > 0 || filters.priceRange[1] < 10000

  const clearAll = () =>
    onChange({
      category: null, brand: null, sizes: [], priceRange: [0, 10000],
      condition: null, search: '', sortBy: 'newest',
    })

  return (
    <div>
      {/* Search + sort row */}
      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={filters.search}
            onChange={e => update({ search: e.target.value })}
            className="pl-9"
          />
        </div>
        <select
          value={filters.sortBy}
          onChange={e => update({ sortBy: e.target.value as FilterState['sortBy'] })}
          className="h-10 rounded-lg border border-input bg-background px-3 text-sm"
        >
          <option value="newest">Newest</option>
          <option value="popular">Most Popular</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
          <option value="rating">Best Rated</option>
        </select>
        <Button
          variant="outline"
          size="icon"
          onClick={() => setOpen(!open)}
          className={cn(open && 'bg-muted')}
          aria-label="Toggle filters"
        >
          <SlidersHorizontal className="h-4 w-4" />
        </Button>
        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={clearAll} className="gap-1">
            <X className="h-3.5 w-3.5" />
            Clear
          </Button>
        )}
      </div>

      {/* Filter panel */}
      {open && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 rounded-xl border bg-muted/30 mb-6">
          {/* Category */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider mb-2 text-muted-foreground">
              Category
            </p>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() =>
                    update({ category: filters.category === cat.id ? null : (cat.id as ProductCategory) })
                  }
                  className={cn(
                    'text-xs px-2.5 py-1 rounded-full border transition-all',
                    filters.category === cat.id
                      ? 'bg-brand-green text-white border-brand-green'
                      : 'bg-background border-input hover:border-brand-green'
                  )}
                >
                  {cat.emoji} {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Brand */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider mb-2 text-muted-foreground">
              Brand
            </p>
            <div className="flex flex-wrap gap-1.5">
              {mockBrands.map(brand => (
                <button
                  key={brand.id}
                  onClick={() =>
                    update({ brand: filters.brand === brand.name ? null : brand.name })
                  }
                  className={cn(
                    'text-xs px-2.5 py-1 rounded-full border transition-all',
                    filters.brand === brand.name
                      ? 'bg-brand-green text-white border-brand-green'
                      : 'bg-background border-input hover:border-brand-green'
                  )}
                >
                  {brand.name}
                </button>
              ))}
            </div>
          </div>

          {/* Price range */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider mb-2 text-muted-foreground">
              Max Price
            </p>
            <input
              type="range"
              min={0}
              max={10000}
              step={100}
              value={filters.priceRange[1]}
              onChange={e => update({ priceRange: [filters.priceRange[0], Number(e.target.value)] })}
              className="w-full accent-brand-green"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>R0</span>
              <span className="font-medium">R{filters.priceRange[1].toLocaleString()}</span>
            </div>
          </div>

          {/* Condition (preloved) */}
          {showCondition && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2 text-muted-foreground">
                Condition
              </p>
              <div className="flex flex-wrap gap-1.5">
                {PRELOVED_CONDITIONS.map(cond => (
                  <button
                    key={cond.id}
                    onClick={() =>
                      update({
                        condition: filters.condition === cond.id ? null : (cond.id as FilterState['condition']),
                      })
                    }
                    className={cn(
                      'text-xs px-2.5 py-1 rounded-full border transition-all',
                      filters.condition === cond.id
                        ? 'bg-brand-green text-white border-brand-green'
                        : 'bg-background border-input hover:border-brand-green'
                    )}
                  >
                    {cond.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Active filter chips */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2 mb-4">
          {filters.category && (
            <span className="flex items-center gap-1 text-xs bg-brand-green/10 text-brand-green px-2.5 py-1 rounded-full">
              {CATEGORIES.find(c => c.id === filters.category)?.label}
              <button onClick={() => update({ category: null })}>
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          {filters.brand && (
            <span className="flex items-center gap-1 text-xs bg-brand-green/10 text-brand-green px-2.5 py-1 rounded-full">
              {filters.brand}
              <button onClick={() => update({ brand: null })}>
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
          {filters.condition && (
            <span className="flex items-center gap-1 text-xs bg-brand-green/10 text-brand-green px-2.5 py-1 rounded-full">
              {PRELOVED_CONDITIONS.find(c => c.id === filters.condition)?.label}
              <button onClick={() => update({ condition: null })}>
                <X className="h-3 w-3" />
              </button>
            </span>
          )}
        </div>
      )}
    </div>
  )
}
