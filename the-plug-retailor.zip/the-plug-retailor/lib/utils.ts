import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { ProductCondition, OrderStatus } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-ZA', {
    style: 'currency',
    currency: 'ZAR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price)
}

export function getConditionLabel(condition: ProductCondition): string {
  const labels: Record<ProductCondition, string> = {
    'new': 'New',
    'like-new': 'Like New',
    'excellent': 'Excellent',
    'good': 'Good',
    'fair': 'Fair',
  }
  return labels[condition]
}

export function getConditionColor(condition: ProductCondition): string {
  const colors: Record<ProductCondition, string> = {
    'new': 'bg-brand-green text-white',
    'like-new': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
    'excellent': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'good': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    'fair': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
  }
  return colors[condition]
}

export function getOrderStatusLabel(status: OrderStatus): string {
  const labels: Record<OrderStatus, string> = {
    'received': 'Order Received',
    'confirmed': 'Confirmed',
    'processing': 'Processing',
    'packed': 'Packed',
    'shipped': 'Shipped',
    'out-for-delivery': 'Out for Delivery',
    'delivered': 'Delivered',
  }
  return labels[status]
}

export function getOrderStatusStep(status: OrderStatus): number {
  const steps: Record<OrderStatus, number> = {
    'received': 0,
    'confirmed': 1,
    'processing': 2,
    'packed': 3,
    'shipped': 4,
    'out-for-delivery': 5,
    'delivered': 6,
  }
  return steps[status]
}

export function calculateDiscount(original: number, current: number): number {
  return Math.round(((original - current) / original) * 100)
}

export function slugify(str: string): string {
  return str.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '')
}

export const CATEGORIES = [
  { id: 'shirts', label: 'Shirts', emoji: '👕' },
  { id: 'caps', label: 'Caps', emoji: '🧢' },
  { id: 'tracksuits', label: 'Tracksuits', emoji: '🩱' },
  { id: 'shoes', label: 'Shoes', emoji: '👟' },
  { id: 'jackets', label: 'Jackets', emoji: '🧥' },
  { id: 'bags', label: 'Bags', emoji: '👜' },
  { id: 'watches', label: 'Watches', emoji: '⌚' },
  { id: 'electronics', label: 'Electronics', emoji: '🎧' },
  { id: 'car-accessories', label: 'Car Accessories', emoji: '🚗' },
  { id: 'home-living', label: 'Home & Living', emoji: '🏠' },
  { id: 'beauty-grooming', label: 'Beauty & Grooming', emoji: '✨' },
]

export const PRELOVED_CONDITIONS = [
  { id: 'like-new', label: 'Like New' },
  { id: 'excellent', label: 'Excellent' },
  { id: 'good', label: 'Good' },
  { id: 'fair', label: 'Fair' },
]

export const SA_PROVINCES = [
  'Gauteng',
  'Western Cape',
  'KwaZulu-Natal',
  'Eastern Cape',
  'Limpopo',
  'Mpumalanga',
  'North West',
  'Free State',
  'Northern Cape',
]
