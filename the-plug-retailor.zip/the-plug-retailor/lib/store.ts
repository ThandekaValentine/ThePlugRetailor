'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { CartItem, Product } from '@/types'

interface CartStore {
  items: CartItem[]
  savedItems: CartItem[]
  addItem: (product: Product, size: string, quantity?: number) => void
  removeItem: (productId: string, size: string) => void
  updateQuantity: (productId: string, size: string, quantity: number) => void
  saveForLater: (productId: string, size: string) => void
  moveToCart: (productId: string, size: string) => void
  clearCart: () => void
  getTotalItems: () => number
  getTotalPrice: () => number
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      savedItems: [],
      addItem: (product, size, quantity = 1) => {
        set(state => {
          const existing = state.items.find(
            i => i.product.id === product.id && i.selectedSize === size
          )
          if (existing) {
            return {
              items: state.items.map(i =>
                i.product.id === product.id && i.selectedSize === size
                  ? { ...i, quantity: i.quantity + quantity }
                  : i
              ),
            }
          }
          return {
            items: [...state.items, { product, quantity, selectedSize: size }],
          }
        })
      },
      removeItem: (productId, size) => {
        set(state => ({
          items: state.items.filter(
            i => !(i.product.id === productId && i.selectedSize === size)
          ),
        }))
      },
      updateQuantity: (productId, size, quantity) => {
        if (quantity <= 0) {
          get().removeItem(productId, size)
          return
        }
        set(state => ({
          items: state.items.map(i =>
            i.product.id === productId && i.selectedSize === size
              ? { ...i, quantity }
              : i
          ),
        }))
      },
      saveForLater: (productId, size) => {
        set(state => {
          const item = state.items.find(
            i => i.product.id === productId && i.selectedSize === size
          )
          if (!item) return state
          return {
            items: state.items.filter(
              i => !(i.product.id === productId && i.selectedSize === size)
            ),
            savedItems: [...state.savedItems, item],
          }
        })
      },
      moveToCart: (productId, size) => {
        set(state => {
          const item = state.savedItems.find(
            i => i.product.id === productId && i.selectedSize === size
          )
          if (!item) return state
          return {
            savedItems: state.savedItems.filter(
              i => !(i.product.id === productId && i.selectedSize === size)
            ),
            items: [...state.items, item],
          }
        })
      },
      clearCart: () => set({ items: [], savedItems: [] }),
      getTotalItems: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
      getTotalPrice: () => get().items.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
    }),
    { name: 'plug-cart' }
  )
)

interface WishlistStore {
  items: Product[]
  addItem: (product: Product) => void
  removeItem: (productId: string) => void
  isWishlisted: (productId: string) => boolean
  toggle: (product: Product) => void
}

export const useWishlistStore = create<WishlistStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: product => {
        set(state => ({
          items: state.items.some(i => i.id === product.id)
            ? state.items
            : [...state.items, product],
        }))
      },
      removeItem: productId => {
        set(state => ({
          items: state.items.filter(i => i.id !== productId),
        }))
      },
      isWishlisted: productId => get().items.some(i => i.id === productId),
      toggle: product => {
        const wishlisted = get().isWishlisted(product.id)
        wishlisted ? get().removeItem(product.id) : get().addItem(product)
      },
    }),
    { name: 'plug-wishlist' }
  )
)
