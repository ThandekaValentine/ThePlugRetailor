export type ProductCondition = 'new' | 'like-new' | 'excellent' | 'good' | 'fair'

export type ProductCategory =
  | 'shirts'
  | 'caps'
  | 'tracksuits'
  | 'shoes'
  | 'jackets'
  | 'bags'
  | 'watches'
  | 'electronics'
  | 'car-accessories'
  | 'home-living'
  | 'beauty-grooming'

export interface Product {
  id: string
  name: string
  brand: string
  description: string
  price: number
  originalPrice?: number
  images: string[]
  category: ProductCategory
  sizes: string[]
  stock: number
  condition: ProductCondition
  type: 'new' | 'preloved'
  rating: number
  reviewCount: number
  tags: string[]
  featured?: boolean
  sku: string
}

export interface CartItem {
  product: Product
  quantity: number
  selectedSize: string
  savedForLater?: boolean
}

export interface Cart {
  items: CartItem[]
  savedItems: CartItem[]
}

export interface User {
  id: string
  name: string
  email: string
  phone?: string
  avatar?: string
  addresses: Address[]
  createdAt: string
}

export interface Address {
  id: string
  label: string
  street: string
  suburb: string
  city: string
  province: string
  postalCode: string
  isDefault: boolean
}

export interface Order {
  id: string
  userId: string
  items: CartItem[]
  status: OrderStatus
  total: number
  shippingAddress: Address
  paymentMethod: string
  deliveryMethod: string
  createdAt: string
  updatedAt: string
  trackingNumber?: string
  estimatedDelivery?: string
}

export type OrderStatus =
  | 'received'
  | 'confirmed'
  | 'processing'
  | 'packed'
  | 'shipped'
  | 'out-for-delivery'
  | 'delivered'

export interface Review {
  id: string
  productId: string
  userId: string
  userName: string
  rating: number
  title: string
  body: string
  createdAt: string
  verified: boolean
}

export interface Brand {
  id: string
  name: string
  logo: string
  description: string
  category: string
  featured: boolean
  origin: string
}

export interface FilterState {
  category: ProductCategory | null
  brand: string | null
  sizes: string[]
  priceRange: [number, number]
  condition: ProductCondition | null
  search: string
  sortBy: 'price-asc' | 'price-desc' | 'newest' | 'popular' | 'rating'
}

export interface AdminStats {
  totalRevenue: number
  totalOrders: number
  totalCustomers: number
  totalProducts: number
  revenueGrowth: number
  ordersGrowth: number
  customersGrowth: number
  lowStockCount: number
}
