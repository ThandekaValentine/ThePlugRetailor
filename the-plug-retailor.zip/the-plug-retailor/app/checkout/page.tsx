'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { CheckCircle, ChevronRight, CreditCard, Building2, Smartphone, Banknote } from 'lucide-react'
import { useCartStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { formatPrice } from '@/lib/utils'
import { SA_PROVINCES } from '@/lib/utils'

const PAYMENT_METHODS = [
  { id: 'payfast', label: 'PayFast', icon: <CreditCard className="h-5 w-5" />, desc: 'Cards, EFT, SnapScan' },
  { id: 'ozow', label: 'Ozow', icon: <Smartphone className="h-5 w-5" />, desc: 'Instant EFT' },
  { id: 'eft', label: 'Manual EFT', icon: <Building2 className="h-5 w-5" />, desc: 'Bank transfer' },
  { id: 'card', label: 'Credit / Debit Card', icon: <Banknote className="h-5 w-5" />, desc: 'Visa, Mastercard' },
]

const DELIVERY_OPTIONS = [
  { id: 'standard', label: 'Standard Delivery', desc: '3–5 business days', price: 99 },
  { id: 'express', label: 'Express Delivery', desc: '1–2 business days', price: 199 },
  { id: 'collection', label: 'Collection Point', desc: 'Pick up near you', price: 0 },
]

export default function CheckoutPage() {
  const { items, getTotalPrice, clearCart } = useCartStore()
  const [step, setStep] = useState(1)
  const [payment, setPayment] = useState('payfast')
  const [delivery, setDelivery] = useState('standard')
  const [placed, setPlaced] = useState(false)

  const subtotal = getTotalPrice()
  const deliveryCost = DELIVERY_OPTIONS.find(d => d.id === delivery)?.price ?? 99
  const total = subtotal + deliveryCost

  const handlePlaceOrder = () => {
    setPlaced(true)
    clearCart()
  }

  if (placed) {
    return (
      <div className="container mx-auto px-4 py-20 text-center max-w-lg">
        <div className="h-20 w-20 rounded-full bg-brand-green/10 flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="h-10 w-10 text-brand-green" />
        </div>
        <h1 className="text-3xl font-bold mb-3">Order Placed! 🎉</h1>
        <p className="text-muted-foreground mb-2">
          Thank you for supporting South African brands.
        </p>
        <p className="text-sm text-muted-foreground mb-8">
          Order confirmation has been sent to your email. Your order number is{' '}
          <span className="font-bold text-foreground">PLUG-{Math.floor(Math.random() * 90000) + 10000}</span>
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button asChild>
            <Link href="/account/orders">Track My Order</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/shop/new">Continue Shopping</Link>
          </Button>
        </div>
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
        <Button asChild><Link href="/shop/new">Shop Now</Link></Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-10 max-w-5xl">
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>

      {/* Steps */}
      <div className="flex items-center gap-2 mb-10 overflow-x-auto pb-2">
        {['Delivery', 'Payment', 'Review'].map((s, i) => (
          <div key={s} className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={() => i + 1 < step && setStep(i + 1)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                step === i + 1
                  ? 'bg-brand-green text-white'
                  : step > i + 1
                  ? 'bg-brand-green/10 text-brand-green'
                  : 'bg-muted text-muted-foreground'
              }`}
            >
              <span className="h-5 w-5 rounded-full border-2 flex items-center justify-center text-xs">
                {step > i + 1 ? '✓' : i + 1}
              </span>
              {s}
            </button>
            {i < 2 && <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />}
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Step 1 — Delivery */}
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-4">Delivery Address</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <Input placeholder="First name" />
                  <Input placeholder="Last name" />
                  <Input placeholder="Phone number" className="sm:col-span-2" />
                  <Input placeholder="Street address" className="sm:col-span-2" />
                  <Input placeholder="Suburb" />
                  <Input placeholder="City" />
                  <select className="h-10 rounded-lg border border-input bg-background px-3 text-sm">
                    <option value="">Select Province</option>
                    {SA_PROVINCES.map(p => <option key={p}>{p}</option>)}
                  </select>
                  <Input placeholder="Postal code" />
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-4">Delivery Method</h2>
                <div className="space-y-3">
                  {DELIVERY_OPTIONS.map(opt => (
                    <label
                      key={opt.id}
                      className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${
                        delivery === opt.id ? 'border-brand-green bg-brand-green/5' : 'hover:border-muted-foreground/30'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="delivery"
                          value={opt.id}
                          checked={delivery === opt.id}
                          onChange={() => setDelivery(opt.id)}
                          className="accent-brand-green"
                        />
                        <div>
                          <p className="font-medium text-sm">{opt.label}</p>
                          <p className="text-xs text-muted-foreground">{opt.desc}</p>
                        </div>
                      </div>
                      <span className="font-semibold text-sm">
                        {opt.price === 0 ? 'FREE' : formatPrice(opt.price)}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <Button size="lg" className="w-full" onClick={() => setStep(2)}>
                Continue to Payment <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}

          {/* Step 2 — Payment */}
          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold mb-4">Payment Method</h2>
              <div className="space-y-3">
                {PAYMENT_METHODS.map(method => (
                  <label
                    key={method.id}
                    className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                      payment === method.id ? 'border-brand-green bg-brand-green/5' : 'hover:border-muted-foreground/30'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value={method.id}
                      checked={payment === method.id}
                      onChange={() => setPayment(method.id)}
                      className="accent-brand-green"
                    />
                    <div className="text-brand-green">{method.icon}</div>
                    <div>
                      <p className="font-medium text-sm">{method.label}</p>
                      <p className="text-xs text-muted-foreground">{method.desc}</p>
                    </div>
                  </label>
                ))}
              </div>

              {(payment === 'card') && (
                <div className="p-4 rounded-xl border bg-muted/30 space-y-3">
                  <Input placeholder="Card number" />
                  <div className="grid grid-cols-2 gap-3">
                    <Input placeholder="MM / YY" />
                    <Input placeholder="CVV" />
                  </div>
                  <Input placeholder="Name on card" />
                </div>
              )}

              <div className="flex gap-3">
                <Button variant="outline" size="lg" onClick={() => setStep(1)}>Back</Button>
                <Button size="lg" className="flex-1" onClick={() => setStep(3)}>
                  Review Order <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 3 — Review */}
          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold mb-4">Review Your Order</h2>
              <div className="space-y-3">
                {items.map(item => (
                  <div key={`${item.product.id}-${item.selectedSize}`} className="flex gap-3 p-3 rounded-xl border">
                    <div className="relative h-16 w-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      <Image src={item.product.images[0]} alt={item.product.name} fill className="object-cover" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{item.product.name}</p>
                      <p className="text-xs text-muted-foreground">{item.product.brand} · Size {item.selectedSize} · Qty {item.quantity}</p>
                    </div>
                    <p className="font-bold text-sm">{formatPrice(item.product.price * item.quantity)}</p>
                  </div>
                ))}
              </div>

              <div className="p-4 rounded-xl border space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Payment</span>
                  <span className="font-medium">{PAYMENT_METHODS.find(m => m.id === payment)?.label}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className="font-medium">{DELIVERY_OPTIONS.find(d => d.id === delivery)?.label}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" size="lg" onClick={() => setStep(2)}>Back</Button>
                <Button size="lg" className="flex-1" onClick={handlePlaceOrder}>
                  Place Order — {formatPrice(total)}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Summary */}
        <div>
          <div className="rounded-2xl border bg-card p-5 sticky top-24">
            <h3 className="font-bold mb-4">Order Summary</h3>
            <div className="space-y-2 text-sm mb-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal ({items.length} items)</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery</span>
                <span>{deliveryCost === 0 ? 'FREE' : formatPrice(deliveryCost)}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold text-base">
                <span>Total</span>
                <span>{formatPrice(total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
