'use client'

import { useState, useMemo } from 'react'
import { getNewProducts } from '@/mock-data/products'
import ProductCard from '@/components/product/product-card'
import ProductFilters from '@/components/product/product-filters'
import { FilterState } from '@/types'
import { Badge } from '@/components/ui/badge'

const defaultFilters: FilterState = {
  category: null,
  brand: null,
  sizes: [],
  priceRange: [0, 10000],
  condition: null,
  search: '',
  sortBy: 'newest',
}

export default function NewProductsPage() {
  const [filters, setFilters] = useState<FilterState>(defaultFilters)
  const allProducts = getNewProducts()

  const filtered = useMemo(() => {
    let products = [...allProducts]

    if (filters.search) {
      const q = filters.search.toLowerCase()
      products = products.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      )
    }

    if (filters.category) {
      products = products.filter(p => p.category === filters.category)
    }

    if (filters.brand) {
      products = products.filter(p => p.brand === filters.brand)
    }

    products = products.filter(
      p => p.price >= filters.priceRange[0] && p.price <= filters.priceRange[1]
    )

    switch (filters.sortBy) {
      case 'price-asc':
        products.sort((a, b) => a.price - b.price)
        break
      case 'price-desc':
        products.sort((a, b) => b.price - a.price)
        break
      case 'rating':
        products.sort((a, b) => b.rating - a.rating)
        break
      case 'popular':
        products.sort((a, b) => b.reviewCount - a.reviewCount)
        break
    }

    return products
  }, [filters, allProducts])

  return (
    <div className="container mx-auto px-4 py-10">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Badge>New Products</Badge>
          <Badge variant="secondary">{filtered.length} items</Badge>
        </div>
        <h1 className="text-3xl font-bold">New South African Products</h1>
        <p className="text-muted-foreground mt-1">
          Brand-new products from 50+ proudly South African brands
        </p>
      </div>

      {/* Filters */}
      <ProductFilters filters={filters} onChange={setFilters} showCondition={false} />

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-4xl mb-4">🔍</p>
          <h3 className="text-lg font-semibold mb-2">No products found</h3>
          <p className="text-muted-foreground">Try adjusting your filters or search terms</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
