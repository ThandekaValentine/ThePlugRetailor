'use client'

import { useState } from 'react'
import { useParams, notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import {
  ShoppingBag, Heart, Share2, Star, ChevronRight, Shield,
  Truck, RefreshCw, CheckCircle
} from 'lucide-react'
import { getProductById, getRelatedProducts } from '@/mock-data/products'
import { getReviewsByProductId } from '@/mock-data/reviews'
import { useCartStore, useWishlistStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import ProductCard from '@/components/product/product-card'
import { formatPrice, getConditionLabel, getConditionColor, cn } from '@/lib/utils'

export default function ProductPage() {
  const { id } = useParams<{ id: string }>()
  const product = getProductById(id)

  if (!product) notFound()

  const reviews = getReviewsByProductId(product.id)
  const related = getRelatedProducts(product)
  const { addItem } = useCartStore()
  const { toggle, isWishlisted } = useWishlistStore()
  const wishlisted = isWishlisted(product.id)

  const [selectedSize, setSelectedSize] = useState(product.sizes[0])
  const [selectedImage, setSelectedImage] = useState(0)
  const [added, setAdded] = useState(false)

  const handleAddToCart = () => {
    addItem(product, selectedSize)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-sm text-muted-foreground mb-8">
        <Link href="/" className="hover:text-foreground">Home</Link>
        <ChevronRight className="h-3.5 w-3.5" />
        <Link href={`/shop/${product.type}`} className="hover:text-foreground capitalize">
          {product.type === 'preloved' ? 'Preloved' : 'New Products'}
        </Link>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="text-foreground truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Product main */}
      <div className="grid lg:grid-cols-2 gap-12 mb-16">
        {/* Images */}
        <div className="space-y-3">
          <div className="relative aspect-square rounded-2xl overflow-hidden bg-muted">
            <Image
              src={product.images[selectedImage]}
              alt={product.name}
              fill
              className="object-cover"
              sizes="(max-width: 1024px) 100vw, 50vw"
              priority
            />
            {product.type === 'preloved' && (
              <div className="absolute top-4 left-4">
                <span className={cn('px-3 py-1 rounded-full text-xs font-semibold', getConditionColor(product.condition))}>
                  {getConditionLabel(product.condition)}
                </span>
              </div>
            )}
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-2">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(i)}
                  className={cn(
                    'relative h-20 w-20 rounded-xl overflow-hidden border-2 transition-all',
                    selectedImage === i ? 'border-brand-green' : 'border-transparent'
                  )}
                >
                  <Image src={img} alt="" fill className="object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="space-y-6">
          <div>
            <p className="text-sm font-semibold text-brand-green uppercase tracking-wider mb-1">
              {product.brand}
            </p>
            <h1 className="text-3xl font-bold mb-3">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center gap-3">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={cn(
                      'h-4 w-4',
                      i < Math.floor(product.rating)
                        ? 'text-brand-gold fill-brand-gold'
                        : 'text-muted'
                    )}
                  />
                ))}
              </div>
              <span className="text-sm font-medium">{product.rating}</span>
              <span className="text-sm text-muted-foreground">({product.reviewCount} reviews)</span>
            </div>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3">
            <span className="text-4xl font-bold">{formatPrice(product.price)}</span>
            {product.originalPrice && (
              <>
                <span className="text-lg text-muted-foreground line-through">
                  {formatPrice(product.originalPrice)}
                </span>
                <Badge variant="destructive">
                  Save {formatPrice(product.originalPrice - product.price)}
                </Badge>
              </>
            )}
          </div>

          {/* Description */}
          <p className="text-muted-foreground leading-relaxed">{product.description}</p>

          {/* Size */}
          {product.sizes.length > 1 && (
            <div>
              <p className="text-sm font-semibold mb-2">Size</p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={cn(
                      'px-4 py-2 rounded-lg border text-sm font-medium transition-all',
                      selectedSize === size
                        ? 'bg-brand-green text-white border-brand-green'
                        : 'border-input hover:border-brand-green'
                    )}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Stock */}
          <div className="flex items-center gap-2">
            {product.stock > 0 ? (
              <>
                <CheckCircle className="h-4 w-4 text-brand-green" />
                <span className="text-sm font-medium text-brand-green">
                  {product.stock <= 5 ? `Only ${product.stock} left in stock` : 'In stock'}
                </span>
              </>
            ) : (
              <span className="text-sm font-medium text-destructive">Out of stock</span>
            )}
          </div>

          {/* CTAs */}
          <div className="flex gap-3">
            <Button
              size="xl"
              className="flex-1"
              onClick={handleAddToCart}
              disabled={product.stock === 0}
            >
              {added ? (
                <>
                  <CheckCircle className="h-5 w-5" /> Added to Cart
                </>
              ) : (
                <>
                  <ShoppingBag className="h-5 w-5" /> Add to Cart
                </>
              )}
            </Button>
            <Button
              size="xl"
              variant="outline"
              onClick={() => toggle(product)}
              className={wishlisted ? 'text-red-500 border-red-200' : ''}
              aria-label="Wishlist"
            >
              <Heart className={cn('h-5 w-5', wishlisted && 'fill-current')} />
            </Button>
            <Button size="xl" variant="outline" aria-label="Share">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>

          {/* Guarantees */}
          <div className="grid grid-cols-3 gap-3 pt-2">
            {[
              { icon: <Truck className="h-4 w-4" />, label: 'Free delivery over R750' },
              { icon: <RefreshCw className="h-4 w-4" />, label: '30-day returns' },
              { icon: <Shield className="h-4 w-4" />, label: 'Secure checkout' },
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-muted/50 text-center">
                <div className="text-brand-green">{item.icon}</div>
                <p className="text-xs font-medium leading-tight">{item.label}</p>
              </div>
            ))}
          </div>

          {/* SKU */}
          <p className="text-xs text-muted-foreground">SKU: {product.sku}</p>
        </div>
      </div>

      {/* Reviews */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>
        {reviews.length === 0 ? (
          <p className="text-muted-foreground">No reviews yet. Be the first!</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {reviews.map(review => (
              <div key={review.id} className="p-5 rounded-2xl border bg-card">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-semibold text-sm">{review.userName}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(review.createdAt).toLocaleDateString('en-ZA')}
                    </p>
                  </div>
                  {review.verified && (
                    <Badge variant="secondary" className="text-[10px]">Verified</Badge>
                  )}
                </div>
                <div className="flex mb-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={cn(
                        'h-3.5 w-3.5',
                        i < review.rating ? 'text-brand-gold fill-brand-gold' : 'text-muted'
                      )}
                    />
                  ))}
                </div>
                <p className="font-medium text-sm mb-1">{review.title}</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{review.body}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Related products */}
      {related.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold mb-6">You Might Also Like</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {related.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
