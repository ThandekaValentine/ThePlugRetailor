'use client'

import { useState, useMemo } from 'react'
import { getPrelovedProducts } from '@/mock-data/products'
import ProductCard from '@/components/product/product-card'
import ProductFilters from '@/components/product/product-filters'
import { FilterState } from '@/types'
import { Badge } from '@/components/ui/badge'
import { RecycleIcon } from 'lucide-react'

const defaultFilters: FilterState = {
  category: null,
  brand: null,
  sizes: [],
  priceRange: [0, 10000],
  condition: null,
  search: '',
  sortBy: 'newest',
}

export default function PrelovedPage() {
  const [filters, setFilters] = useState<FilterState>(defaultFilters)
  const allProducts = getPrelovedProducts()

  const filtered = useMemo(() => {
    let products = [...allProducts]

    if (filters.search) {
      const q = filters.search.toLowerCase()
      products = products.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q)
      )
    }

    if (filters.category) {
      products = products.filter(p => p.category === filters.category)
    }

    if (filters.brand) {
      products = products.filter(p => p.brand === filters.brand)
    }

    if (filters.condition) {
      products = products.filter(p => p.condition === filters.condition)
    }

    products = products.filter(
      p => p.price >= filters.priceRange[0] && p.price <= filters.priceRange[1]
    )

    switch (filters.sortBy) {
      case 'price-asc':
        products.sort((a, b) => a.price - b.price)
        break
      case 'price-desc':
        products.sort((a, b) => b.price - a.price)
        break
      case 'rating':
        products.sort((a, b) => b.rating - a.rating)
        break
    }

    return products
  }, [filters, allProducts])

  return (
    <div className="container mx-auto px-4 py-10">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Badge className="bg-foreground text-background">
            <RecycleIcon className="h-3 w-3 mr-1" />
            Preloved
          </Badge>
          <Badge variant="secondary">{filtered.length} items</Badge>
        </div>
        <h1 className="text-3xl font-bold">Preloved South African Products</h1>
        <p className="text-muted-foreground mt-1">
          Genuine SA brands, preloved with care. Sustainable, affordable, and proudly local.
        </p>
      </div>

      {/* Condition guide */}
      <div className="flex flex-wrap gap-2 mb-6 p-4 rounded-xl bg-muted/50">
        <span className="text-xs font-semibold text-muted-foreground mr-2 self-center">Condition guide:</span>
        {[
          { label: 'Like New', color: 'bg-emerald-100 text-emerald-800', desc: 'Barely worn' },
          { label: 'Excellent', color: 'bg-blue-100 text-blue-800', desc: 'Light use' },
          { label: 'Good', color: 'bg-yellow-100 text-yellow-800', desc: 'Normal wear' },
          { label: 'Fair', color: 'bg-orange-100 text-orange-800', desc: 'Visible wear' },
        ].map(c => (
          <span key={c.label} className={`${c.color} text-xs px-2.5 py-1 rounded-full font-medium`}>
            {c.label} — {c.desc}
          </span>
        ))}
      </div>

      {/* Filters */}
      <ProductFilters filters={filters} onChange={setFilters} showCondition={true} />

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-4xl mb-4">♻️</p>
          <h3 className="text-lg font-semibold mb-2">No preloved items found</h3>
          <p className="text-muted-foreground">Try adjusting your filters or check back soon</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
