import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight, Star, Shield, Truck, RefreshCw, Heart, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import ProductCard from '@/components/product/product-card'
import { getFeaturedProducts } from '@/mock-data/products'
import { getFeaturedBrands } from '@/mock-data/brands'
import { CATEGORIES, formatPrice } from '@/lib/utils'

export default function HomePage() {
  const featuredProducts = getFeaturedProducts()
  const featuredBrands = getFeaturedBrands()

  return (
    <div className="w-full">
      {/* HERO */}
      <section className="relative min-h-[85vh] flex items-center overflow-hidden bg-gradient-to-br from-[#f8f9fa] to-white dark:from-zinc-900 dark:to-background">
        {/* SA flag accent strip */}
        <div className="absolute top-0 left-0 right-0 h-1 flex">
          <div className="flex-1 bg-brand-green" />
          <div className="flex-1 bg-brand-gold" />
          <div className="flex-1 bg-brand-red" />
          <div className="flex-1 bg-brand-blue" />
        </div>

        <div className="container mx-auto px-4 py-20 grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in">
            <div className="inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-sm">
              <span className="h-2 w-2 rounded-full bg-brand-green animate-pulse" />
              🇿🇦 100% South African Brands Only
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05]">
              Your Home
              <br />
              for <span className="text-brand-green">SA Brands</span>
            </h1>

            <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
              The Plug Retailor exists to support and promote South African brands — new and
              preloved. Shop local. Wear local. Be proud.
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="xl" asChild className="group">
                <Link href="/shop/new">
                  Shop New Products
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button size="xl" variant="black" asChild>
                <Link href="/shop/preloved">
                  Shop Preloved
                  <RefreshCw className="h-5 w-5" />
                </Link>
              </Button>
            </div>

            <div className="flex items-center gap-6 pt-2">
              <div className="text-center">
                <p className="text-2xl font-bold">50+</p>
                <p className="text-xs text-muted-foreground">SA Brands</p>
              </div>
              <div className="h-8 w-px bg-border" />
              <div className="text-center">
                <p className="text-2xl font-bold">1K+</p>
                <p className="text-xs text-muted-foreground">Products</p>
              </div>
              <div className="h-8 w-px bg-border" />
              <div className="text-center">
                <p className="text-2xl font-bold">4.9★</p>
                <p className="text-xs text-muted-foreground">Avg Rating</p>
              </div>
            </div>
          </div>

          {/* Hero image grid */}
          <div className="hidden lg:grid grid-cols-2 gap-4">
            {featuredProducts.slice(0, 4).map((product, i) => (
              <Link
                key={product.id}
                href={`/shop/product/${product.id}`}
                className={`relative overflow-hidden rounded-2xl bg-muted group ${i === 0 ? 'row-span-2' : ''}`}
                style={{ aspectRatio: i === 0 ? '3/4' : '1' }}
              >
                <Image
                  src={product.images[0]}
                  alt={product.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute bottom-3 left-3 right-3">
                  <div className="bg-white/90 dark:bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2">
                    <p className="text-xs font-medium truncate">{product.name}</p>
                    <p className="text-xs text-brand-green font-bold">{formatPrice(product.price)}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* SHOP TYPE CTAs */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-6">
          <Link
            href="/shop/new"
            className="group relative overflow-hidden rounded-3xl bg-brand-green text-white p-10 flex flex-col justify-between min-h-[280px] hover:shadow-xl transition-shadow"
          >
            <div>
              <Badge className="bg-white/20 text-white mb-4">New Arrivals</Badge>
              <h2 className="text-4xl font-bold mb-3">Shop New</h2>
              <p className="opacity-80 max-w-xs">
                Brand-new products from the best South African brands. Straight from the shelf to you.
              </p>
            </div>
            <div className="flex items-center gap-2 font-semibold">
              Browse New Products <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </div>
            <div className="absolute bottom-0 right-0 w-48 h-48 rounded-full bg-white/10 translate-x-16 translate-y-16" />
          </Link>

          <Link
            href="/shop/preloved"
            className="group relative overflow-hidden rounded-3xl bg-foreground text-background p-10 flex flex-col justify-between min-h-[280px] hover:shadow-xl transition-shadow"
          >
            <div>
              <Badge className="bg-white/20 text-white mb-4">♻️ Sustainable</Badge>
              <h2 className="text-4xl font-bold mb-3">Shop Preloved</h2>
              <p className="opacity-70 max-w-xs">
                Genuine SA brands, preloved with care. Save money, reduce waste, keep it local.
              </p>
            </div>
            <div className="flex items-center gap-2 font-semibold">
              Browse Preloved <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </div>
            <div className="absolute bottom-0 right-0 w-48 h-48 rounded-full bg-white/5 translate-x-16 translate-y-16" />
          </Link>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Shop by Category</h2>
          <Link href="/shop/new" className="text-sm text-brand-green font-medium hover:underline">
            View all →
          </Link>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          {CATEGORIES.map(cat => (
            <Link
              key={cat.id}
              href={`/shop/new?category=${cat.id}`}
              className="flex flex-col items-center gap-2 p-4 rounded-2xl border bg-card hover:border-brand-green hover:bg-brand-green/5 transition-all group text-center"
            >
              <span className="text-3xl group-hover:scale-110 transition-transform">{cat.emoji}</span>
              <span className="text-xs font-medium leading-tight">{cat.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold">Featured Products</h2>
            <p className="text-sm text-muted-foreground mt-1">Handpicked from our top SA brands</p>
          </div>
          <Link href="/shop/new" className="text-sm text-brand-green font-medium hover:underline hidden sm:block">
            View all →
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {featuredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* FEATURED BRANDS */}
      <section className="bg-muted/30 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-2">Featured South African Brands</h2>
            <p className="text-muted-foreground">Every brand on The Plug Retailor is proudly South African 🇿🇦</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {featuredBrands.map(brand => (
              <Link
                key={brand.id}
                href={`/shop/new?brand=${encodeURIComponent(brand.name)}`}
                className="group bg-background rounded-2xl border p-6 hover:border-brand-green hover:shadow-md transition-all text-center"
              >
                <div className="h-16 w-16 rounded-2xl bg-brand-green/10 mx-auto mb-3 flex items-center justify-center">
                  <span className="text-2xl font-bold text-brand-green">
                    {brand.name.charAt(0)}
                  </span>
                </div>
                <h3 className="font-semibold text-sm mb-1 group-hover:text-brand-green transition-colors">
                  {brand.name}
                </h3>
                <p className="text-xs text-muted-foreground line-clamp-2">{brand.description}</p>
                <p className="text-xs text-brand-green mt-2 font-medium">{brand.origin}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* WHY SHOP LOCAL */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <Badge variant="gold" className="mb-4">Why Shop Local?</Badge>
          <h2 className="text-3xl font-bold mb-3">Support South Africa</h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Every rand you spend on a local brand keeps a South African employed, a dream alive, and our economy growing.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              icon: '🇿🇦',
              title: 'Proudly South African',
              desc: 'Every brand and product on our platform is 100% South African. No exceptions.',
            },
            {
              icon: '💼',
              title: 'Support Local Jobs',
              desc: 'Shopping local keeps South Africans employed and helps build sustainable businesses.',
            },
            {
              icon: '♻️',
              title: 'Preloved = Sustainable',
              desc: 'Our preloved marketplace extends the life of quality products and reduces textile waste.',
            },
            {
              icon: '🏆',
              title: 'Premium Quality',
              desc: 'South African brands are world-class. We only list the best, so you shop with confidence.',
            },
            {
              icon: '🚀',
              title: 'Fast Local Delivery',
              desc: 'Ships from right here in South Africa. No waiting weeks for overseas deliveries.',
            },
            {
              icon: '🤝',
              title: 'Trusted Marketplace',
              desc: 'Every seller and product is vetted. Shop new or preloved with complete peace of mind.',
            },
          ].map((item, i) => (
            <div key={i} className="p-6 rounded-2xl border bg-card">
              <div className="text-4xl mb-3">{item.icon}</div>
              <h3 className="font-semibold mb-2">{item.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SPECIAL OFFERS */}
      <section className="bg-brand-green text-white py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div>
              <Badge className="bg-brand-gold text-black mb-3">🔥 Hot Deals</Badge>
              <h2 className="text-3xl font-bold mb-2">Special Offers This Week</h2>
              <p className="opacity-80">Save up to 40% on selected South African brands</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="lg" variant="black" asChild>
                <Link href="/shop/new?sale=true">
                  View All Deals
                </Link>
              </Button>
              <Button size="lg" className="bg-white text-brand-green hover:bg-white/90" asChild>
                <Link href="/shop/preloved">
                  Shop Preloved Deals
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST BADGES */}
      <section className="border-t">
        <div className="container mx-auto px-4 py-10">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
            {[
              { icon: <Truck className="h-6 w-6" />, label: 'Free Delivery', sub: 'Orders over R750' },
              { icon: <RefreshCw className="h-6 w-6" />, label: '30-Day Returns', sub: 'Hassle-free' },
              { icon: <Shield className="h-6 w-6" />, label: 'Secure Payment', sub: 'PayFast & Ozow' },
              { icon: <Heart className="h-6 w-6" />, label: '100% Local', sub: 'SA brands only' },
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center gap-2">
                <div className="text-brand-green">{item.icon}</div>
                <p className="font-semibold text-sm">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <Badge variant="secondary" className="mb-4">Stay in the Loop</Badge>
          <h2 className="text-3xl font-bold mb-3">Get SA Brand News First</h2>
          <p className="text-muted-foreground mb-8">
            New arrivals, exclusive deals, and the stories behind your favourite South African brands — straight to your inbox.
          </p>
          <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="your@email.com"
              className="flex-1 h-12 rounded-xl border border-input bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-brand-green"
            />
            <Button size="lg" className="h-12">
              Subscribe
              <CheckCircle className="h-4 w-4" />
            </Button>
          </form>
          <p className="text-xs text-muted-foreground mt-3">
            No spam. Unsubscribe any time. POPIA compliant.
          </p>
        </div>
      </section>
    </div>
  )
}
