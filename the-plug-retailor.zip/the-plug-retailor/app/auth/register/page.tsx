import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function RegisterPage() {
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="h-12 w-12 rounded-xl bg-brand-green flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-xl">P</span>
          </div>
          <h1 className="text-2xl font-bold">Create your account</h1>
          <p className="text-muted-foreground mt-1">Join thousands of SA brand supporters</p>
        </div>

        <div className="rounded-2xl border bg-card p-8 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase">First Name</label>
              <Input placeholder="Thabo" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase">Last Name</label>
              <Input placeholder="Nkosi" />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Email</label>
            <Input type="email" placeholder="your@email.com" />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Phone</label>
            <Input type="tel" placeholder="071 000 0000" />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Password</label>
            <Input type="password" placeholder="Minimum 8 characters" />
          </div>

          <label className="flex items-start gap-2 text-xs text-muted-foreground cursor-pointer">
            <input type="checkbox" className="mt-0.5 accent-brand-green" />
            I agree to the{' '}
            <Link href="/terms" className="text-brand-green hover:underline">Terms & Conditions</Link>
            {' '}and{' '}
            <Link href="/privacy" className="text-brand-green hover:underline">Privacy Policy</Link>
          </label>

          <label className="flex items-start gap-2 text-xs text-muted-foreground cursor-pointer">
            <input type="checkbox" className="mt-0.5 accent-brand-green" />
            Subscribe to newsletter for SA brand news and deals
          </label>

          <Button size="lg" className="w-full">Create Account</Button>

          <p className="text-center text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-brand-green font-medium hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
