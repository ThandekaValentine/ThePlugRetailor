import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Mail } from 'lucide-react'

export default function ForgotPasswordPage() {
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="h-12 w-12 rounded-full bg-brand-green/10 flex items-center justify-center mx-auto mb-4">
            <Mail className="h-6 w-6 text-brand-green" />
          </div>
          <h1 className="text-2xl font-bold">Reset your password</h1>
          <p className="text-muted-foreground mt-2 text-sm">Enter your email and we'll send you a reset link.</p>
        </div>

        <div className="rounded-2xl border bg-card p-8 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Email</label>
            <Input type="email" placeholder="your@email.com" />
          </div>
          <Button size="lg" className="w-full">Send Reset Link</Button>
          <p className="text-center text-sm text-muted-foreground">
            <Link href="/auth/login" className="text-brand-green hover:underline">Back to sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
