import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function LoginPage() {
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="h-12 w-12 rounded-xl bg-brand-green flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-xl">P</span>
          </div>
          <h1 className="text-2xl font-bold">Welcome back</h1>
          <p className="text-muted-foreground mt-1">Sign in to your Plug Retailor account</p>
        </div>

        <div className="rounded-2xl border bg-card p-8 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase">Email</label>
            <Input type="email" placeholder="your@email.com" />
          </div>
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="text-xs font-semibold text-muted-foreground uppercase">Password</label>
              <Link href="/auth/forgot-password" className="text-xs text-brand-green hover:underline">Forgot password?</Link>
            </div>
            <Input type="password" placeholder="Your password" />
          </div>

          <Button size="lg" className="w-full">Sign In</Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t" /></div>
            <div className="relative text-center"><span className="bg-card px-3 text-xs text-muted-foreground">or</span></div>
          </div>

          <Button size="lg" variant="outline" className="w-full">Continue with Google</Button>

          <p className="text-center text-sm text-muted-foreground">
            Don't have an account?{' '}
            <Link href="/auth/register" className="text-brand-green font-medium hover:underline">Create one</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
