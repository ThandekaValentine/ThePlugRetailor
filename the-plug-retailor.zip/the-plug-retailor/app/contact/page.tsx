import { Mail, Phone, MapPin, Facebook, Instagram, Twitter, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-5xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-3">Get in Touch</h1>
        <p className="text-muted-foreground max-w-md mx-auto">
          We'd love to hear from you. Our team is here to help with any questions about orders, brands, or selling on The Plug Retailor.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Contact info */}
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold mb-4">Contact Details</h2>
            <div className="space-y-4">
              {[
                { icon: <Phone className="h-5 w-5" />, label: 'Phone', value: '+27 11 000 0000', sub: 'Mon–Fri, 8am–5pm' },
                { icon: <Mail className="h-5 w-5" />, label: 'Email', value: 'hello@theplugretailor.co.za', sub: 'We reply within 24 hours' },
                { icon: <MapPin className="h-5 w-5" />, label: 'Address', value: '123 Nelson Mandela Square, Sandton, Johannesburg, 2196', sub: 'By appointment only' },
                { icon: <Clock className="h-5 w-5" />, label: 'Hours', value: 'Monday – Friday: 8am – 5pm', sub: 'Saturday: 9am – 1pm' },
              ].map(item => (
                <div key={item.label} className="flex gap-4 p-4 rounded-xl border bg-card">
                  <div className="text-brand-green mt-0.5">{item.icon}</div>
                  <div>
                    <p className="text-xs text-muted-foreground">{item.label}</p>
                    <p className="font-medium text-sm">{item.value}</p>
                    <p className="text-xs text-muted-foreground">{item.sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold mb-4">Follow Us</h2>
            <div className="flex gap-3">
              {[
                { icon: <Facebook className="h-5 w-5" />, label: 'Facebook', href: '#' },
                { icon: <Instagram className="h-5 w-5" />, label: 'Instagram', href: '#' },
                { icon: <Twitter className="h-5 w-5" />, label: 'X / Twitter', href: '#' },
                { icon: <span className="font-bold text-sm">TT</span>, label: 'TikTok', href: '#' },
              ].map(s => (
                <a
                  key={s.label}
                  href={s.href}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl border hover:border-brand-green hover:text-brand-green transition-all text-sm"
                >
                  {s.icon}
                  <span className="hidden sm:inline">{s.label}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Map placeholder */}
          <div className="rounded-2xl border bg-muted h-56 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <MapPin className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm font-medium">Map Placeholder</p>
              <p className="text-xs">Google Maps integration</p>
            </div>
          </div>
        </div>

        {/* Contact form */}
        <div>
          <h2 className="text-xl font-bold mb-4">Send Us a Message</h2>
          <form className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <Input placeholder="Your name" />
              <Input placeholder="Your email" type="email" />
            </div>
            <Input placeholder="Subject" />
            <select className="w-full h-10 rounded-lg border border-input bg-background px-3 text-sm text-muted-foreground">
              <option value="">Topic</option>
              <option>Order enquiry</option>
              <option>Returns & refunds</option>
              <option>Product question</option>
              <option>Sell on The Plug Retailor</option>
              <option>General enquiry</option>
            </select>
            <textarea
              rows={5}
              placeholder="Your message..."
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-brand-green focus:ring-offset-2"
            />
            <Button size="lg" className="w-full">Send Message</Button>
          </form>
        </div>
      </div>
    </div>
  )
}
