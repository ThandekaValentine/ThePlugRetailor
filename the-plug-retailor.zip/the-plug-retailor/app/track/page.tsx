'use client'

import { useState } from 'react'
import { Search, Package, CheckCircle } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { mockOrders } from '@/mock-data/orders'
import { getOrderStatusLabel, getOrderStatusStep } from '@/lib/utils'
import { OrderStatus } from '@/types'

const ORDER_STEPS: OrderStatus[] = [
  'received', 'confirmed', 'processing', 'packed', 'shipped', 'out-for-delivery', 'delivered'
]

export default function TrackPage() {
  const [query, setQuery] = useState('')
  const [order, setOrder] = useState<(typeof mockOrders)[0] | null>(null)
  const [notFound, setNotFound] = useState(false)

  const handleSearch = () => {
    const found = mockOrders.find(
      o => o.id.toLowerCase() === query.toLowerCase() ||
        o.trackingNumber?.toLowerCase() === query.toLowerCase()
    )
    if (found) { setOrder(found); setNotFound(false) }
    else { setOrder(null); setNotFound(true) }
  }

  const currentStep = order ? getOrderStatusStep(order.status) : -1

  return (
    <div className="container mx-auto px-4 py-16 max-w-2xl">
      <div className="text-center mb-10">
        <Package className="h-12 w-12 mx-auto text-brand-green mb-4" />
        <h1 className="text-3xl font-bold mb-2">Track Your Order</h1>
        <p className="text-muted-foreground">Enter your order number or tracking number below</p>
      </div>

      <div className="flex gap-2 mb-8">
        <Input
          placeholder="e.g. ORD-2024-001 or PLUG-TRK-001234"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSearch()}
        />
        <Button onClick={handleSearch}>
          <Search className="h-4 w-4" />
          Track
        </Button>
      </div>

      {/* Demo hint */}
      <div className="bg-muted/50 rounded-xl p-3 mb-8 text-xs text-muted-foreground">
        <strong>Demo orders to try:</strong> ORD-2024-001, ORD-2024-002, ORD-2024-003
      </div>

      {notFound && (
        <div className="text-center p-8 rounded-2xl border">
          <p className="text-lg font-semibold mb-2">Order not found</p>
          <p className="text-sm text-muted-foreground">Please check your order number and try again.</p>
        </div>
      )}

      {order && (
        <div className="rounded-2xl border bg-card p-6 space-y-6">
          {/* Order header */}
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Order Number</p>
              <p className="font-bold text-lg">{order.id}</p>
              {order.trackingNumber && (
                <p className="text-xs text-muted-foreground mt-1">Tracking: {order.trackingNumber}</p>
              )}
            </div>
            <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
              order.status === 'delivered' ? 'bg-brand-green/10 text-brand-green' :
              order.status === 'shipped' || order.status === 'out-for-delivery' ? 'bg-blue-100 text-blue-700' :
              'bg-yellow-100 text-yellow-700'
            }`}>
              {getOrderStatusLabel(order.status)}
            </span>
          </div>

          {/* Progress bar */}
          <div>
            <div className="flex items-center mb-2">
              <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-brand-green rounded-full transition-all duration-500"
                  style={{ width: `${((currentStep + 1) / ORDER_STEPS.length) * 100}%` }}
                />
              </div>
            </div>
            <div className="grid grid-cols-7 gap-1">
              {ORDER_STEPS.map((step, i) => (
                <div key={step} className="flex flex-col items-center gap-1">
                  <div className={`h-5 w-5 rounded-full flex items-center justify-center ${
                    i <= currentStep ? 'bg-brand-green' : 'bg-muted'
                  }`}>
                    {i <= currentStep && <CheckCircle className="h-3 w-3 text-white" />}
                  </div>
                  <p className="text-[9px] text-center text-muted-foreground leading-tight">
                    {getOrderStatusLabel(step)}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Items */}
          <div>
            <p className="text-sm font-semibold mb-3">Items in this order</p>
            {order.items.map(item => (
              <div key={item.product.id} className="flex gap-3 text-sm">
                <div className="h-12 w-12 rounded-lg bg-muted flex-shrink-0 overflow-hidden relative">
                  {item.product.images[0] && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.product.images[0]} alt={item.product.name} className="object-cover w-full h-full" />
                  )}
                </div>
                <div>
                  <p className="font-medium">{item.product.name}</p>
                  <p className="text-xs text-muted-foreground">{item.product.brand} · Size {item.selectedSize} · Qty {item.quantity}</p>
                </div>
              </div>
            ))}
          </div>

          {order.estimatedDelivery && (
            <div className="bg-brand-green/5 rounded-xl p-3 text-sm">
              <p className="font-medium text-brand-green">
                Estimated Delivery: {new Date(order.estimatedDelivery).toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long' })}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
