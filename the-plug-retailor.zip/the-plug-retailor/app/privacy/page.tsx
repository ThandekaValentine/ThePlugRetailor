export default function PrivacyPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-3xl">
      <h1 className="text-4xl font-bold mb-3">Privacy Policy</h1>
      <p className="text-muted-foreground mb-2">Last updated: November 2024</p>
      <div className="inline-flex items-center gap-2 bg-brand-green/10 text-brand-green text-xs px-3 py-1.5 rounded-full mb-10 font-medium">
        🇿🇦 POPIA Compliant — Protection of Personal Information Act 4 of 2013
      </div>

      <div className="space-y-8 text-sm leading-relaxed text-muted-foreground">
        {[
          {
            title: '1. Information We Collect',
            body: 'We collect personal information you provide when creating an account (name, email, phone number, address), placing orders, contacting support, or subscribing to our newsletter. We also automatically collect usage data such as IP address, browser type, and pages visited.',
          },
          {
            title: '2. How We Use Your Information',
            body: 'We use your personal information to: process and fulfil orders; send order updates and tracking information; provide customer support; send marketing communications (only with your consent); improve our platform and services; comply with legal obligations.',
          },
          {
            title: '3. POPIA Compliance',
            body: 'The Plug Retailor processes personal information in compliance with the Protection of Personal Information Act 4 of 2013 (POPIA). You have the right to: access your personal information; correct inaccurate information; object to the processing of your information; request deletion of your information. To exercise these rights, contact privacy@theplugretailor.co.za',
          },
          {
            title: '4. Information Sharing',
            body: 'We do not sell or rent your personal information to third parties. We share information only with: delivery partners (to fulfil orders); payment processors (to process payments); service providers bound by confidentiality agreements; authorities where required by law.',
          },
          {
            title: '5. Data Security',
            body: 'We implement industry-standard security measures including SSL encryption, secure payment processing through PayFast and Ozow, and regular security audits. No system is 100% secure, but we take your data protection seriously.',
          },
          {
            title: '6. Cookies',
            body: 'We use cookies to improve your browsing experience, remember your preferences, and analyse website traffic. You can control cookie settings in your browser. Disabling cookies may affect some features of our website.',
          },
          {
            title: '7. Data Retention',
            body: 'We retain your personal information for as long as necessary to fulfil the purposes for which it was collected, typically 5 years for transaction records in compliance with South African tax law, and 1 year for marketing preferences.',
          },
          {
            title: '8. Contact',
            body: 'For privacy enquiries or to exercise your POPIA rights, contact our Information Officer at: privacy@theplugretailor.co.za\n\nThe Plug Retailor\n123 Nelson Mandela Square\nSandton, Johannesburg, 2196',
          },
        ].map(s => (
          <div key={s.title} id={s.title.toLowerCase().replace(/\s+/g, '-')}>
            <h2 className="text-lg font-bold text-foreground mb-2">{s.title}</h2>
            <p className="whitespace-pre-line">{s.body}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
