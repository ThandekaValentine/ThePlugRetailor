'use client'

import { useState } from 'react'
import Link from 'next/link'
import { User, ShoppingBag, Heart, MapPin, LogOut, Edit3, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const navItems = [
  { icon: <User className="h-4 w-4" />, label: 'Profile', href: '/account/profile', active: true },
  { icon: <ShoppingBag className="h-4 w-4" />, label: 'Orders', href: '/account/orders' },
  { icon: <Heart className="h-4 w-4" />, label: 'Wishlist', href: '/account/wishlist' },
  { icon: <MapPin className="h-4 w-4" />, label: 'Addresses', href: '/account/addresses' },
]

export default function ProfilePage() {
  const [saved, setSaved] = useState(false)

  return (
    <div className="container mx-auto px-4 py-10 max-w-4xl">
      <div className="grid md:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="md:col-span-1">
          <div className="flex items-center gap-3 mb-6 p-4 rounded-2xl bg-muted/50">
            <div className="h-12 w-12 rounded-full bg-brand-green flex items-center justify-center text-white font-bold text-lg">T</div>
            <div>
              <p className="font-semibold text-sm">Thabo Nkosi</p>
              <p className="text-xs text-muted-foreground">thabo@email.com</p>
            </div>
          </div>
          <nav className="space-y-1">
            {navItems.map(item => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  item.active ? 'bg-brand-green text-white' : 'hover:bg-muted'
                }`}
              >
                {item.icon}
                {item.label}
              </Link>
            ))}
            <button className="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-muted w-full text-destructive mt-4">
              <LogOut className="h-4 w-4" />
              Sign Out
            </button>
          </nav>
        </div>

        {/* Main */}
        <div className="md:col-span-3">
          <h1 className="text-2xl font-bold mb-6">My Profile</h1>
          <div className="rounded-2xl border bg-card p-6 space-y-6">
            <div className="flex items-center gap-4 pb-4 border-b">
              <div className="h-20 w-20 rounded-full bg-brand-green flex items-center justify-center text-white font-bold text-3xl">T</div>
              <div>
                <p className="font-bold text-lg">Thabo Nkosi</p>
                <p className="text-sm text-muted-foreground">Member since September 2024</p>
                <Button size="sm" variant="outline" className="mt-2 gap-1.5">
                  <Edit3 className="h-3.5 w-3.5" /> Change Photo
                </Button>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">First Name</label>
                <Input defaultValue="Thabo" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Last Name</label>
                <Input defaultValue="Nkosi" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Email</label>
                <Input defaultValue="thabo.nkosi@email.com" type="email" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Phone</label>
                <Input defaultValue="071 234 5678" />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase">Current Password</label>
              <Input type="password" placeholder="Enter to change password" />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">New Password</label>
                <Input type="password" placeholder="New password" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground uppercase">Confirm Password</label>
                <Input type="password" placeholder="Confirm password" />
              </div>
            </div>

            <Button
              className="gap-2"
              onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2500) }}
            >
              {saved ? <><CheckCircle className="h-4 w-4" /> Saved!</> : 'Save Changes'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
