import Link from 'next/link'
import { ShoppingBag, User, Heart, MapPin, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { mockOrders } from '@/mock-data/orders'
import { formatPrice, getOrderStatusLabel } from '@/lib/utils'

const navItems = [
  { icon: <User className="h-4 w-4" />, label: 'Profile', href: '/account/profile' },
  { icon: <ShoppingBag className="h-4 w-4" />, label: 'Orders', href: '/account/orders', active: true },
  { icon: <Heart className="h-4 w-4" />, label: 'Wishlist', href: '/account/wishlist' },
  { icon: <MapPin className="h-4 w-4" />, label: 'Addresses', href: '/account/addresses' },
]

const statusVariant = (status: string) => {
  if (status === 'delivered') return 'default'
  if (status === 'shipped' || status === 'out-for-delivery') return 'secondary'
  return 'outline'
}

export default function OrdersPage() {
  return (
    <div className="container mx-auto px-4 py-10 max-w-4xl">
      <div className="grid md:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="md:col-span-1">
          <div className="flex items-center gap-3 mb-6 p-4 rounded-2xl bg-muted/50">
            <div className="h-12 w-12 rounded-full bg-brand-green flex items-center justify-center text-white font-bold text-lg">T</div>
            <div>
              <p className="font-semibold text-sm">Thabo Nkosi</p>
              <p className="text-xs text-muted-foreground">thabo@email.com</p>
            </div>
          </div>
          <nav className="space-y-1">
            {navItems.map(item => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  item.active ? 'bg-brand-green text-white' : 'hover:bg-muted'
                }`}
              >
                {item.icon}
                {item.label}
              </Link>
            ))}
          </nav>
        </div>

        {/* Orders */}
        <div className="md:col-span-3">
          <h1 className="text-2xl font-bold mb-6">My Orders</h1>
          <div className="space-y-4">
            {mockOrders.map(order => (
              <div key={order.id} className="rounded-2xl border bg-card p-5">
                <div className="flex items-start justify-between mb-3 gap-2">
                  <div>
                    <p className="font-bold">{order.id}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  </div>
                  <Badge variant={statusVariant(order.status) as any}>
                    {getOrderStatusLabel(order.status)}
                  </Badge>
                </div>

                <div className="flex gap-2 mb-3 overflow-x-auto pb-1">
                  {order.items.map(item => (
                    <div
                      key={item.product.id}
                      className="h-14 w-14 rounded-xl bg-muted flex-shrink-0 overflow-hidden relative"
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={item.product.images[0]} alt={item.product.name} className="object-cover w-full h-full" />
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <p className="font-semibold">{formatPrice(order.total)}</p>
                  <div className="flex gap-2">
                    <Link href={`/track?order=${order.id}`}>
                      <Button size="sm" variant="outline" className="gap-1.5">
                        <ChevronRight className="h-3.5 w-3.5" /> Track
                      </Button>
                    </Link>
                    {order.status === 'delivered' && (
                      <Button size="sm" variant="outline">Write Review</Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
