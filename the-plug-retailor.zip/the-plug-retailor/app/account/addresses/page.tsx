'use client'

import { useState } from 'react'
import Link from 'next/link'
import { User, ShoppingBag, Heart, MapPin, Plus, Pencil, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { SA_PROVINCES } from '@/lib/utils'

const navItems = [
  { icon: <User className="h-4 w-4" />, label: 'Profile', href: '/account/profile' },
  { icon: <ShoppingBag className="h-4 w-4" />, label: 'Orders', href: '/account/orders' },
  { icon: <Heart className="h-4 w-4" />, label: 'Wishlist', href: '/account/wishlist' },
  { icon: <MapPin className="h-4 w-4" />, label: 'Addresses', href: '/account/addresses', active: true },
]

const defaultAddresses = [
  { id: 'a1', label: 'Home', street: '12 Nelson Mandela Drive', suburb: 'Sandton', city: 'Johannesburg', province: 'Gauteng', postalCode: '2196', isDefault: true },
  { id: 'a2', label: 'Work', street: '45 Commissioner Street', suburb: 'CBD', city: 'Johannesburg', province: 'Gauteng', postalCode: '2001', isDefault: false },
]

export default function AddressesPage() {
  const [addresses, setAddresses] = useState(defaultAddresses)
  const [adding, setAdding] = useState(false)

  return (
    <div className="container mx-auto px-4 py-10 max-w-4xl">
      <div className="grid md:grid-cols-4 gap-8">
        <div className="md:col-span-1">
          <div className="flex items-center gap-3 mb-6 p-4 rounded-2xl bg-muted/50">
            <div className="h-12 w-12 rounded-full bg-brand-green flex items-center justify-center text-white font-bold text-lg">T</div>
            <div>
              <p className="font-semibold text-sm">Thabo Nkosi</p>
              <p className="text-xs text-muted-foreground">thabo@email.com</p>
            </div>
          </div>
          <nav className="space-y-1">
            {navItems.map(item => (
              <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${item.active ? 'bg-brand-green text-white' : 'hover:bg-muted'}`}>
                {item.icon}{item.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="md:col-span-3">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">Saved Addresses</h1>
            <Button size="sm" onClick={() => setAdding(true)} className="gap-1.5">
              <Plus className="h-4 w-4" /> Add Address
            </Button>
          </div>

          <div className="space-y-4">
            {addresses.map(addr => (
              <div key={addr.id} className={`p-5 rounded-2xl border bg-card ${addr.isDefault ? 'border-brand-green' : ''}`}>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-sm">{addr.label}</span>
                      {addr.isDefault && <span className="text-[10px] bg-brand-green text-white px-2 py-0.5 rounded-full">Default</span>}
                    </div>
                    <p className="text-sm text-muted-foreground">{addr.street}</p>
                    <p className="text-sm text-muted-foreground">{addr.suburb}, {addr.city}, {addr.province}, {addr.postalCode}</p>
                  </div>
                  <div className="flex gap-1">
                    <button className="p-2 hover:bg-muted rounded-lg"><Pencil className="h-4 w-4" /></button>
                    <button className="p-2 hover:bg-muted rounded-lg text-destructive" onClick={() => setAddresses(a => a.filter(x => x.id !== addr.id))}>
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {adding && (
            <div className="mt-6 p-6 rounded-2xl border bg-card">
              <h3 className="font-bold mb-4">New Address</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <Input placeholder="Label (e.g. Home, Work)" className="sm:col-span-2" />
                <Input placeholder="Street address" className="sm:col-span-2" />
                <Input placeholder="Suburb" />
                <Input placeholder="City" />
                <select className="h-10 rounded-lg border border-input bg-background px-3 text-sm">
                  <option>Select Province</option>
                  {SA_PROVINCES.map(p => <option key={p}>{p}</option>)}
                </select>
                <Input placeholder="Postal code" />
              </div>
              <div className="flex gap-3 mt-4">
                <Button onClick={() => setAdding(false)}>Save Address</Button>
                <Button variant="outline" onClick={() => setAdding(false)}>Cancel</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
