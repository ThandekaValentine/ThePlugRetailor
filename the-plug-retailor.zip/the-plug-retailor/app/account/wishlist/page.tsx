'use client'

import Link from 'next/link'
import { User, ShoppingBag, Heart, MapPin } from 'lucide-react'
import { useWishlistStore } from '@/lib/store'
import ProductCard from '@/components/product/product-card'
import { Button } from '@/components/ui/button'

const navItems = [
  { icon: <User className="h-4 w-4" />, label: 'Profile', href: '/account/profile' },
  { icon: <ShoppingBag className="h-4 w-4" />, label: 'Orders', href: '/account/orders' },
  { icon: <Heart className="h-4 w-4" />, label: 'Wishlist', href: '/account/wishlist', active: true },
  { icon: <MapPin className="h-4 w-4" />, label: 'Addresses', href: '/account/addresses' },
]

export default function WishlistPage() {
  const { items } = useWishlistStore()

  return (
    <div className="container mx-auto px-4 py-10 max-w-4xl">
      <div className="grid md:grid-cols-4 gap-8">
        <div className="md:col-span-1">
          <div className="flex items-center gap-3 mb-6 p-4 rounded-2xl bg-muted/50">
            <div className="h-12 w-12 rounded-full bg-brand-green flex items-center justify-center text-white font-bold text-lg">T</div>
            <div>
              <p className="font-semibold text-sm">Thabo Nkosi</p>
              <p className="text-xs text-muted-foreground">thabo@email.com</p>
            </div>
          </div>
          <nav className="space-y-1">
            {navItems.map(item => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  item.active ? 'bg-brand-green text-white' : 'hover:bg-muted'
                }`}
              >
                {item.icon}
                {item.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="md:col-span-3">
          <h1 className="text-2xl font-bold mb-6">My Wishlist ({items.length})</h1>
          {items.length === 0 ? (
            <div className="text-center py-16">
              <Heart className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="font-semibold mb-2">Your wishlist is empty</p>
              <p className="text-sm text-muted-foreground mb-6">Tap the heart on any product to save it here.</p>
              <Button asChild><Link href="/shop/new">Browse Products</Link></Button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {items.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
