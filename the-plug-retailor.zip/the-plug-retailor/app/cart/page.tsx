'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Minus, Plus, Trash2, ShoppingBag, BookmarkPlus, ArrowRight } from 'lucide-react'
import { useCartStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatPrice, getConditionLabel } from '@/lib/utils'

export default function CartPage() {
  const { items, savedItems, removeItem, updateQuantity, saveForLater, moveToCart, getTotalPrice } =
    useCartStore()

  const subtotal = getTotalPrice()
  const shipping = subtotal >= 750 ? 0 : 99
  const total = subtotal + shipping

  if (items.length === 0 && savedItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
        <h1 className="text-2xl font-bold mb-2">Your cart is empty</h1>
        <p className="text-muted-foreground mb-8">
          Start shopping South African brands and add items to your cart
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button asChild size="lg">
            <Link href="/shop/new">Shop New Products</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/shop/preloved">Shop Preloved</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-8">
        Your Cart
        {items.length > 0 && (
          <span className="ml-3 text-lg font-normal text-muted-foreground">
            ({items.length} {items.length === 1 ? 'item' : 'items'})
          </span>
        )}
      </h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Cart items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map(item => (
            <div
              key={`${item.product.id}-${item.selectedSize}`}
              className="flex gap-4 p-4 rounded-2xl border bg-card"
            >
              <Link href={`/shop/product/${item.product.id}`} className="flex-shrink-0">
                <div className="relative h-24 w-24 rounded-xl overflow-hidden bg-muted">
                  <Image
                    src={item.product.images[0]}
                    alt={item.product.name}
                    fill
                    className="object-cover"
                  />
                </div>
              </Link>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-brand-green font-semibold uppercase">
                      {item.product.brand}
                    </p>
                    <Link href={`/shop/product/${item.product.id}`}>
                      <h3 className="font-semibold hover:text-brand-green transition-colors">
                        {item.product.name}
                      </h3>
                    </Link>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-muted-foreground">Size: {item.selectedSize}</span>
                      {item.product.type === 'preloved' && (
                        <Badge variant="secondary" className="text-[10px]">
                          {getConditionLabel(item.product.condition)}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <p className="font-bold whitespace-nowrap">
                    {formatPrice(item.product.price * item.quantity)}
                  </p>
                </div>

                <div className="flex items-center justify-between mt-3">
                  {/* Qty */}
                  <div className="flex items-center gap-2 border rounded-lg">
                    <button
                      className="p-1.5 hover:bg-muted rounded-l-lg transition-colors"
                      onClick={() =>
                        updateQuantity(item.product.id, item.selectedSize, item.quantity - 1)
                      }
                    >
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="px-2 text-sm font-medium min-w-[1.5rem] text-center">
                      {item.quantity}
                    </span>
                    <button
                      className="p-1.5 hover:bg-muted rounded-r-lg transition-colors"
                      onClick={() =>
                        updateQuantity(item.product.id, item.selectedSize, item.quantity + 1)
                      }
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-1">
                    <button
                      className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-muted"
                      onClick={() => saveForLater(item.product.id, item.selectedSize)}
                      title="Save for later"
                    >
                      <BookmarkPlus className="h-4 w-4" />
                    </button>
                    <button
                      className="p-2 text-muted-foreground hover:text-destructive transition-colors rounded-lg hover:bg-muted"
                      onClick={() => removeItem(item.product.id, item.selectedSize)}
                      title="Remove"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Saved for later */}
          {savedItems.length > 0 && (
            <div>
              <h3 className="font-semibold text-muted-foreground mb-3">
                Saved for Later ({savedItems.length})
              </h3>
              {savedItems.map(item => (
                <div
                  key={`saved-${item.product.id}-${item.selectedSize}`}
                  className="flex gap-4 p-4 rounded-2xl border bg-muted/30"
                >
                  <div className="relative h-20 w-20 rounded-xl overflow-hidden bg-muted">
                    <Image src={item.product.images[0]} alt={item.product.name} fill className="object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{item.product.name}</p>
                    <p className="text-sm text-muted-foreground">{item.product.brand} · {item.selectedSize}</p>
                    <p className="font-bold mt-1">{formatPrice(item.product.price)}</p>
                    <button
                      className="text-xs text-brand-green font-medium mt-2 hover:underline"
                      onClick={() => moveToCart(item.product.id, item.selectedSize)}
                    >
                      Move to cart
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Order summary */}
        <div>
          <div className="rounded-2xl border bg-card p-6 sticky top-24">
            <h2 className="font-bold text-lg mb-4">Order Summary</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Shipping</span>
                <span className={shipping === 0 ? 'text-brand-green font-medium' : ''}>
                  {shipping === 0 ? 'FREE' : formatPrice(shipping)}
                </span>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-muted-foreground">
                  Add {formatPrice(750 - subtotal)} more for free delivery
                </p>
              )}
              <div className="border-t pt-3">
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>{formatPrice(total)}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Incl. VAT</p>
              </div>
            </div>

            {/* Delivery estimate */}
            <div className="bg-muted/50 rounded-xl p-3 mb-4 text-xs">
              <p className="font-medium mb-1">📦 Estimated Delivery</p>
              <p className="text-muted-foreground">Standard: 3–5 business days</p>
              <p className="text-muted-foreground">Express: 1–2 business days</p>
            </div>

            <Button size="lg" className="w-full" asChild>
              <Link href="/checkout">
                Proceed to Checkout
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>

            <div className="flex items-center justify-center gap-3 mt-4 text-xs text-muted-foreground">
              <span>PayFast</span>
              <span>·</span>
              <span>Ozow</span>
              <span>·</span>
              <span>EFT</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
