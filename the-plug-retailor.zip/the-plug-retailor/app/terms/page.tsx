export default function TermsPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-3xl">
      <h1 className="text-4xl font-bold mb-3">Terms & Conditions</h1>
      <p className="text-muted-foreground mb-10">Last updated: November 2024</p>

      <div className="space-y-8 text-sm leading-relaxed text-muted-foreground">
        {[
          { title: '1. Acceptance of Terms', body: 'By accessing or using The Plug Retailor website and services, you agree to be bound by these Terms & Conditions. If you do not agree to these terms, please do not use our services.' },
          { title: '2. South African Brands Only', body: 'The Plug Retailor is exclusively a marketplace for South African brands. All products listed on our platform must originate from South African brands or businesses. We reserve the right to remove any product that does not meet this criterion.' },
          { title: '3. User Accounts', body: 'You must create an account to make purchases. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You must be 18 years or older to create an account and make purchases.' },
          { title: '4. Product Listings', body: 'All product descriptions, images, and pricing are provided in good faith. We reserve the right to correct any errors. Prices are in South African Rand (ZAR) and include VAT where applicable.' },
          { title: '5. Preloved Marketplace', body: 'For preloved items, The Plug Retailor acts as a platform connecting buyers and sellers. While we vet all sellers and grade all items, we cannot guarantee absolute accuracy of every listing. We encourage buyers to review the condition grading carefully.' },
          { title: '6. Intellectual Property', body: 'All content on The Plug Retailor, including logos, text, images, and design, is the property of The Plug Retailor or its content suppliers and is protected by South African copyright law.' },
          { title: '7. Limitation of Liability', body: 'To the fullest extent permitted by law, The Plug Retailor shall not be liable for any indirect, incidental, or consequential damages arising from use of our platform. Our maximum liability shall not exceed the value of the order in question.' },
          { title: '8. Governing Law', body: 'These Terms & Conditions are governed by the laws of the Republic of South Africa. Any disputes shall be subject to the exclusive jurisdiction of the South African courts.' },
          { title: '9. Contact', body: 'For questions regarding these Terms, contact us at legal@theplugretailor.co.za' },
        ].map(s => (
          <div key={s.title}>
            <h2 className="text-lg font-bold text-foreground mb-2">{s.title}</h2>
            <p>{s.body}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
