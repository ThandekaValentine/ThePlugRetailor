import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { getFeaturedBrands } from '@/mock-data/brands'

export default function AboutPage() {
  const brands = getFeaturedBrands()

  return (
    <div className="container mx-auto px-4 py-16 max-w-4xl">
      {/* Hero */}
      <div className="text-center mb-16">
        <div className="inline-flex gap-1 mb-6">
          <div className="h-2 w-16 rounded-full bg-brand-green" />
          <div className="h-2 w-16 rounded-full bg-brand-gold" />
          <div className="h-2 w-16 rounded-full bg-brand-red" />
        </div>
        <h1 className="text-5xl font-bold mb-4">About The Plug Retailor</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Your Home for South African Brands — a trusted marketplace dedicated to supporting, celebrating, and growing local businesses.
        </p>
      </div>

      {/* Mission */}
      <div className="grid md:grid-cols-2 gap-8 mb-16">
        <div className="p-8 rounded-3xl bg-brand-green text-white">
          <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
          <p className="opacity-90 leading-relaxed">
            The Plug Retailor exists to support and promote South African brands by providing a trusted online marketplace for both brand-new and preloved products. We believe in the power of buying local to build our economy, support livelihoods, and celebrate our rich cultural heritage.
          </p>
        </div>
        <div className="p-8 rounded-3xl border bg-card">
          <h2 className="text-2xl font-bold mb-4">What Makes Us Different</h2>
          <ul className="space-y-3 text-sm text-muted-foreground">
            {[
              '🇿🇦 100% South African brands — no exceptions',
              '♻️ New and preloved in one marketplace',
              '✅ Every brand and product is vetted',
              '🚀 Fast local shipping from SA warehouses',
              '🤝 Direct support for local entrepreneurs',
              '🌱 Committed to sustainable fashion',
            ].map(item => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Story */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-6">Our Story</h2>
        <div className="prose prose-lg max-w-none text-muted-foreground space-y-4">
          <p>
            The Plug Retailor was born out of a simple frustration: South African brands deserve better. Great local brands were being overlooked in favour of international imports, while talented South African entrepreneurs struggled to find trusted platforms to sell their products.
          </p>
          <p>
            We built The Plug Retailor to change that. A marketplace that puts South African brands front and centre, where customers can shop with confidence knowing everything they buy is genuinely local.
          </p>
          <p>
            Our preloved marketplace takes it one step further — giving quality South African products a second life, reducing waste, and making premium local brands accessible to everyone.
          </p>
        </div>
      </div>

      {/* Brands */}
      <div id="brands" className="mb-16">
        <h2 className="text-3xl font-bold mb-8">Our Featured Brands</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {brands.map(brand => (
            <Link
              key={brand.id}
              href={`/shop/new?brand=${encodeURIComponent(brand.name)}`}
              className="group p-5 rounded-2xl border bg-card hover:border-brand-green hover:shadow-md transition-all"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="h-12 w-12 rounded-xl bg-brand-green/10 flex items-center justify-center">
                  <span className="text-xl font-bold text-brand-green">{brand.name.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="font-semibold group-hover:text-brand-green transition-colors">{brand.name}</h3>
                  <p className="text-xs text-brand-green">{brand.origin}</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3">{brand.description}</p>
            </Link>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="text-center p-12 rounded-3xl bg-muted/50">
        <h2 className="text-2xl font-bold mb-3">Ready to Shop Local?</h2>
        <p className="text-muted-foreground mb-6">Discover the best of South Africa, one product at a time.</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button size="lg" asChild><Link href="/shop/new">Shop New Products</Link></Button>
          <Button size="lg" variant="outline" asChild><Link href="/shop/preloved">Shop Preloved</Link></Button>
        </div>
      </div>
    </div>
  )
}
