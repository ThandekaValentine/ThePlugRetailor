'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Plus, Search, Pencil, Trash2, Eye } from 'lucide-react'
import { mockProducts } from '@/mock-data/products'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { formatPrice } from '@/lib/utils'

const adminNav = [
  { label: 'Dashboard', href: '/admin' },
  { label: 'Products', href: '/admin/products', active: true },
  { label: 'Orders', href: '/admin/orders' },
  { label: 'Customers', href: '/admin/customers' },
  { label: 'Inventory', href: '/admin/inventory' },
  { label: 'Analytics', href: '/admin/analytics' },
]

export default function AdminProductsPage() {
  const [search, setSearch] = useState('')
  const [products, setProducts] = useState(mockProducts)

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.brand.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="container mx-auto px-4 py-10 max-w-7xl">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Product Management</h1>
        <Button className="gap-1.5">
          <Plus className="h-4 w-4" /> Add Product
        </Button>
      </div>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {adminNav.map(item => (
          <Link key={item.href} href={item.href} className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${item.active ? 'bg-brand-green text-white' : 'bg-muted hover:bg-muted/80'}`}>
            {item.label}
          </Link>
        ))}
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <div className="rounded-2xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 border-b">
              <tr className="text-xs text-muted-foreground uppercase tracking-wider">
                <th className="text-left p-4">Product</th>
                <th className="text-left p-4">Brand</th>
                <th className="text-left p-4">Category</th>
                <th className="text-left p-4">Type</th>
                <th className="text-right p-4">Price</th>
                <th className="text-right p-4">Stock</th>
                <th className="text-right p-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map(product => (
                <tr key={product.id} className="hover:bg-muted/30 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="relative h-10 w-10 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                        <Image src={product.images[0]} alt={product.name} fill className="object-cover" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium truncate max-w-[180px]">{product.name}</p>
                        <p className="text-xs text-muted-foreground">{product.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground">{product.brand}</td>
                  <td className="p-4 capitalize text-muted-foreground">{product.category.replace('-', ' ')}</td>
                  <td className="p-4">
                    <Badge variant={product.type === 'new' ? 'default' : 'secondary'}>
                      {product.type}
                    </Badge>
                  </td>
                  <td className="p-4 text-right font-medium">{formatPrice(product.price)}</td>
                  <td className="p-4 text-right">
                    <span className={`font-semibold ${product.stock <= 5 ? 'text-red-500' : product.stock <= 10 ? 'text-orange-500' : 'text-brand-green'}`}>
                      {product.stock}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center justify-end gap-1">
                      <Link href={`/shop/product/${product.id}`}>
                        <button className="p-1.5 rounded hover:bg-muted"><Eye className="h-4 w-4" /></button>
                      </Link>
                      <button className="p-1.5 rounded hover:bg-muted text-brand-green"><Pencil className="h-4 w-4" /></button>
                      <button
                        className="p-1.5 rounded hover:bg-muted text-destructive"
                        onClick={() => setProducts(prev => prev.filter(p => p.id !== product.id))}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <p className="text-xs text-muted-foreground mt-3">{filtered.length} products shown</p>
    </div>
  )
}
