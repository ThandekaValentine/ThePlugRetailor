import Link from 'next/link'
import { mockCustomers } from '@/mock-data/orders'
import { formatPrice } from '@/lib/utils'

const adminNav = [
  { label: 'Dashboard', href: '/admin' },
  { label: 'Products', href: '/admin/products' },
  { label: 'Orders', href: '/admin/orders' },
  { label: 'Customers', href: '/admin/customers', active: true },
  { label: 'Inventory', href: '/admin/inventory' },
  { label: 'Analytics', href: '/admin/analytics' },
]

export default function AdminCustomersPage() {
  return (
    <div className="container mx-auto px-4 py-10 max-w-7xl">
      <h1 className="text-3xl font-bold mb-8">Customer Management</h1>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {adminNav.map(item => (
          <Link key={item.href} href={item.href} className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${item.active ? 'bg-brand-green text-white' : 'bg-muted hover:bg-muted/80'}`}>
            {item.label}
          </Link>
        ))}
      </div>

      <div className="rounded-2xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 border-b">
              <tr className="text-xs text-muted-foreground uppercase tracking-wider">
                <th className="text-left p-4">Customer</th>
                <th className="text-left p-4">Phone</th>
                <th className="text-left p-4">Joined</th>
                <th className="text-right p-4">Orders</th>
                <th className="text-right p-4">Total Spent</th>
                <th className="text-right p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {mockCustomers.map(c => (
                <tr key={c.id} className="hover:bg-muted/30 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-full bg-brand-green/10 flex items-center justify-center text-sm font-bold text-brand-green">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium">{c.name}</p>
                        <p className="text-xs text-muted-foreground">{c.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-muted-foreground">{c.phone}</td>
                  <td className="p-4 text-muted-foreground">{new Date(c.createdAt).toLocaleDateString('en-ZA')}</td>
                  <td className="p-4 text-right">{c.orders}</td>
                  <td className="p-4 text-right font-semibold">{formatPrice(c.totalSpent)}</td>
                  <td className="p-4 text-right">
                    <span className={`text-[10px] px-2 py-1 rounded-full font-medium ${c.status === 'active' ? 'bg-brand-green/10 text-brand-green' : 'bg-muted text-muted-foreground'}`}>
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
