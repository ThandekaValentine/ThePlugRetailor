import Link from 'next/link'
import { TrendingUp, ShoppingBag, Users, ArrowUp } from 'lucide-react'
import { formatPrice } from '@/lib/utils'

const adminNav = [
  { label: 'Dashboard', href: '/admin' },
  { label: 'Products', href: '/admin/products' },
  { label: 'Orders', href: '/admin/orders' },
  { label: 'Customers', href: '/admin/customers' },
  { label: 'Inventory', href: '/admin/inventory' },
  { label: 'Analytics', href: '/admin/analytics', active: true },
]

const monthlyRevenue = [
  { month: 'Jun', value: 12400 },
  { month: 'Jul', value: 15800 },
  { month: 'Aug', value: 14200 },
  { month: 'Sep', value: 18900 },
  { month: 'Oct', value: 22100 },
  { month: 'Nov', value: 31450 },
]

const topProducts = [
  { name: 'Joburg Streets Tracksuit', brand: 'Khaya Sport', revenue: 23382, units: 18 },
  { name: 'Highveld Chronograph', brand: 'Tambo Time', revenue: 17495, units: 5 },
  { name: 'Ndebele Runner', brand: 'Veld & Co', revenue: 15192, units: 8 },
  { name: 'Soweto Sound System', brand: 'Rhythm Republic', revenue: 11495, units: 5 },
  { name: 'Ubuntu Classic Tee', brand: 'Ubuntu Threads', revenue: 8376, units: 24 },
]

const maxRevenue = Math.max(...monthlyRevenue.map(m => m.value))

export default function AdminAnalyticsPage() {
  return (
    <div className="container mx-auto px-4 py-10 max-w-7xl">
      <h1 className="text-3xl font-bold mb-2">Analytics</h1>
      <p className="text-muted-foreground mb-8">Mock analytics data — connect your real data source</p>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {adminNav.map(item => (
          <Link key={item.href} href={item.href} className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${item.active ? 'bg-brand-green text-white' : 'bg-muted hover:bg-muted/80'}`}>
            {item.label}
          </Link>
        ))}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Revenue (Nov)', value: formatPrice(31450), change: '+43%', icon: <TrendingUp className="h-5 w-5" /> },
          { label: 'Orders (Nov)', value: '89', change: '+27%', icon: <ShoppingBag className="h-5 w-5" /> },
          { label: 'New Customers', value: '142', change: '+18%', icon: <Users className="h-5 w-5" /> },
          { label: 'Avg Order Value', value: formatPrice(1476), change: '+12%', icon: <ArrowUp className="h-5 w-5" /> },
        ].map(kpi => (
          <div key={kpi.label} className="rounded-2xl border bg-card p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-muted-foreground">{kpi.label}</span>
              <span className="text-brand-green">{kpi.icon}</span>
            </div>
            <p className="text-2xl font-bold mb-1">{kpi.value}</p>
            <p className="text-xs text-brand-green font-medium">{kpi.change} vs last month</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        {/* Revenue chart (bar) */}
        <div className="rounded-2xl border bg-card p-6">
          <h2 className="font-bold mb-6">Monthly Revenue</h2>
          <div className="flex items-end gap-3 h-40">
            {monthlyRevenue.map(m => (
              <div key={m.month} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-[10px] text-muted-foreground">{formatPrice(m.value).replace('R', 'R')}</span>
                <div
                  className="w-full rounded-t-md bg-brand-green transition-all"
                  style={{ height: `${(m.value / maxRevenue) * 100}%` }}
                />
                <span className="text-xs text-muted-foreground">{m.month}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Category breakdown */}
        <div className="rounded-2xl border bg-card p-6">
          <h2 className="font-bold mb-4">Revenue by Category</h2>
          <div className="space-y-3">
            {[
              { label: 'Tracksuits', pct: 32, value: 'R23,382' },
              { label: 'Watches', pct: 24, value: 'R17,495' },
              { label: 'Shoes', pct: 21, value: 'R15,192' },
              { label: 'Electronics', pct: 16, value: 'R11,495' },
              { label: 'Shirts', pct: 7, value: 'R5,120' },
            ].map(cat => (
              <div key={cat.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span>{cat.label}</span>
                  <span className="font-medium">{cat.value} ({cat.pct}%)</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-brand-green rounded-full" style={{ width: `${cat.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top products */}
      <div className="rounded-2xl border bg-card p-6">
        <h2 className="font-bold mb-4">Top Performing Products</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground uppercase tracking-wider border-b">
                <th className="text-left pb-3">Product</th>
                <th className="text-right pb-3">Units Sold</th>
                <th className="text-right pb-3">Revenue</th>
                <th className="text-right pb-3">Share</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {topProducts.map((p, i) => (
                <tr key={p.name} className="hover:bg-muted/30">
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-muted-foreground w-4">{i + 1}</span>
                      <div>
                        <p className="font-medium">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{p.brand}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 text-right">{p.units}</td>
                  <td className="py-3 text-right font-semibold">{formatPrice(p.revenue)}</td>
                  <td className="py-3 text-right text-xs text-brand-green font-medium">
                    {Math.round((p.revenue / topProducts.reduce((a, b) => a + b.revenue, 0)) * 100)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
