'use client'

import { useState } from 'react'
import Link from 'next/link'
import { AlertTriangle, CheckCircle } from 'lucide-react'
import { mockProducts } from '@/mock-data/products'
import { Input } from '@/components/ui/input'

const adminNav = [
  { label: 'Dashboard', href: '/admin' },
  { label: 'Products', href: '/admin/products' },
  { label: 'Orders', href: '/admin/orders' },
  { label: 'Customers', href: '/admin/customers' },
  { label: 'Inventory', href: '/admin/inventory', active: true },
  { label: 'Analytics', href: '/admin/analytics' },
]

export default function AdminInventoryPage() {
  const [stock, setStock] = useState<Record<string, number>>(
    Object.fromEntries(mockProducts.map(p => [p.id, p.stock]))
  )

  const lowCount = Object.values(stock).filter(s => s <= 8).length
  const outCount = Object.values(stock).filter(s => s === 0).length

  return (
    <div className="container mx-auto px-4 py-10 max-w-7xl">
      <h1 className="text-3xl font-bold mb-2">Inventory Management</h1>
      <p className="text-muted-foreground mb-8">Update stock levels and track low-stock items.</p>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {adminNav.map(item => (
          <Link key={item.href} href={item.href} className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${item.active ? 'bg-brand-green text-white' : 'bg-muted hover:bg-muted/80'}`}>
            {item.label}
          </Link>
        ))}
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="rounded-2xl border bg-card p-4">
          <p className="text-xs text-muted-foreground mb-1">Total Products</p>
          <p className="text-2xl font-bold">{mockProducts.length}</p>
        </div>
        <div className={`rounded-2xl border p-4 ${lowCount > 0 ? 'bg-orange-50 dark:bg-orange-950 border-orange-200' : 'bg-card'}`}>
          <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
            <AlertTriangle className="h-3 w-3 text-orange-500" /> Low Stock
          </p>
          <p className="text-2xl font-bold text-orange-600">{lowCount}</p>
        </div>
        <div className={`rounded-2xl border p-4 ${outCount > 0 ? 'bg-red-50 dark:bg-red-950 border-red-200' : 'bg-card'}`}>
          <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
            <AlertTriangle className="h-3 w-3 text-red-500" /> Out of Stock
          </p>
          <p className="text-2xl font-bold text-red-600">{outCount}</p>
        </div>
      </div>

      <div className="rounded-2xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 border-b">
              <tr className="text-xs text-muted-foreground uppercase tracking-wider">
                <th className="text-left p-4">Product</th>
                <th className="text-left p-4">SKU</th>
                <th className="text-left p-4">Type</th>
                <th className="text-center p-4">Current Stock</th>
                <th className="text-center p-4">Update Stock</th>
                <th className="text-center p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {mockProducts.map(product => {
                const currentStock = stock[product.id] ?? product.stock
                return (
                  <tr key={product.id} className={`hover:bg-muted/30 transition-colors ${currentStock === 0 ? 'bg-red-50/50 dark:bg-red-950/20' : currentStock <= 5 ? 'bg-orange-50/50 dark:bg-orange-950/20' : ''}`}>
                    <td className="p-4">
                      <p className="font-medium">{product.name}</p>
                      <p className="text-xs text-muted-foreground">{product.brand}</p>
                    </td>
                    <td className="p-4 text-xs text-muted-foreground font-mono">{product.sku}</td>
                    <td className="p-4 capitalize text-xs">{product.type}</td>
                    <td className="p-4 text-center font-bold text-lg">{currentStock}</td>
                    <td className="p-4">
                      <div className="flex items-center justify-center">
                        <Input
                          type="number"
                          min={0}
                          defaultValue={currentStock}
                          className="w-20 text-center"
                          onChange={e => setStock(prev => ({ ...prev, [product.id]: Number(e.target.value) }))}
                        />
                      </div>
                    </td>
                    <td className="p-4 text-center">
                      {currentStock === 0 ? (
                        <span className="text-[10px] px-2 py-1 rounded-full bg-red-100 text-red-700 font-medium">Out of Stock</span>
                      ) : currentStock <= 5 ? (
                        <span className="text-[10px] px-2 py-1 rounded-full bg-orange-100 text-orange-700 font-medium flex items-center gap-1 justify-center">
                          <AlertTriangle className="h-3 w-3" /> Critical
                        </span>
                      ) : currentStock <= 10 ? (
                        <span className="text-[10px] px-2 py-1 rounded-full bg-yellow-100 text-yellow-700 font-medium">Low</span>
                      ) : (
                        <span className="text-[10px] px-2 py-1 rounded-full bg-brand-green/10 text-brand-green font-medium flex items-center gap-1 justify-center">
                          <CheckCircle className="h-3 w-3" /> Good
                        </span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
