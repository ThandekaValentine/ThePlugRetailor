import Link from 'next/link'
import { mockOrders } from '@/mock-data/orders'
import { Badge } from '@/components/ui/badge'
import { formatPrice, getOrderStatusLabel } from '@/lib/utils'

const adminNav = [
  { label: 'Dashboard', href: '/admin' },
  { label: 'Products', href: '/admin/products' },
  { label: 'Orders', href: '/admin/orders', active: true },
  { label: 'Customers', href: '/admin/customers' },
  { label: 'Inventory', href: '/admin/inventory' },
  { label: 'Analytics', href: '/admin/analytics' },
]

export default function AdminOrdersPage() {
  return (
    <div className="container mx-auto px-4 py-10 max-w-7xl">
      <h1 className="text-3xl font-bold mb-8">Orders Management</h1>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {adminNav.map(item => (
          <Link key={item.href} href={item.href} className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${item.active ? 'bg-brand-green text-white' : 'bg-muted hover:bg-muted/80'}`}>
            {item.label}
          </Link>
        ))}
      </div>

      <div className="rounded-2xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 border-b">
              <tr className="text-xs text-muted-foreground uppercase tracking-wider">
                <th className="text-left p-4">Order ID</th>
                <th className="text-left p-4">Date</th>
                <th className="text-left p-4">Items</th>
                <th className="text-left p-4">Payment</th>
                <th className="text-left p-4">Delivery</th>
                <th className="text-right p-4">Total</th>
                <th className="text-right p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {mockOrders.map(order => (
                <tr key={order.id} className="hover:bg-muted/30 transition-colors">
                  <td className="p-4 font-medium">{order.id}</td>
                  <td className="p-4 text-muted-foreground">{new Date(order.createdAt).toLocaleDateString('en-ZA')}</td>
                  <td className="p-4">{order.items.length} item(s)</td>
                  <td className="p-4 text-muted-foreground">{order.paymentMethod}</td>
                  <td className="p-4 text-muted-foreground">{order.deliveryMethod}</td>
                  <td className="p-4 text-right font-semibold">{formatPrice(order.total)}</td>
                  <td className="p-4 text-right">
                    <select
                      defaultValue={order.status}
                      className="text-xs border rounded-lg px-2 py-1 bg-background"
                    >
                      {['received','confirmed','processing','packed','shipped','out-for-delivery','delivered'].map(s => (
                        <option key={s} value={s}>{getOrderStatusLabel(s as any)}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
