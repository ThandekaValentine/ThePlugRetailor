import Link from 'next/link'
import { TrendingUp, ShoppingBag, Users, Package, AlertTriangle, ArrowRight, ArrowUp } from 'lucide-react'
import { mockOrders, mockCustomers } from '@/mock-data/orders'
import { mockProducts } from '@/mock-data/products'
import { formatPrice, getOrderStatusLabel } from '@/lib/utils'

const stats = [
  { label: 'Total Revenue', value: formatPrice(187450), growth: '+18%', icon: <TrendingUp className="h-5 w-5" />, color: 'text-brand-green' },
  { label: 'Total Orders', value: '342', growth: '+12%', icon: <ShoppingBag className="h-5 w-5" />, color: 'text-blue-500' },
  { label: 'Customers', value: '1,204', growth: '+9%', icon: <Users className="h-5 w-5" />, color: 'text-purple-500' },
  { label: 'Products', value: mockProducts.length.toString(), growth: '+5%', icon: <Package className="h-5 w-5" />, color: 'text-orange-500' },
]

const adminNav = [
  { label: 'Dashboard', href: '/admin', active: true },
  { label: 'Products', href: '/admin/products' },
  { label: 'Orders', href: '/admin/orders' },
  { label: 'Customers', href: '/admin/customers' },
  { label: 'Inventory', href: '/admin/inventory' },
  { label: 'Analytics', href: '/admin/analytics' },
]

const lowStock = mockProducts.filter(p => p.stock <= 8)

export default function AdminDashboard() {
  return (
    <div className="container mx-auto px-4 py-10 max-w-7xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">The Plug Retailor — Seller Portal</p>
        </div>
        <Link href="/" className="text-sm text-brand-green hover:underline">← Back to store</Link>
      </div>

      {/* Admin nav */}
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {adminNav.map(item => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              item.active ? 'bg-brand-green text-white' : 'bg-muted hover:bg-muted/80'
            }`}
          >
            {item.label}
          </Link>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(stat => (
          <div key={stat.label} className="rounded-2xl border bg-card p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-muted-foreground uppercase font-medium">{stat.label}</span>
              <span className={stat.color}>{stat.icon}</span>
            </div>
            <p className="text-2xl font-bold mb-1">{stat.value}</p>
            <div className="flex items-center gap-1 text-brand-green text-xs font-medium">
              <ArrowUp className="h-3 w-3" /> {stat.growth} this month
            </div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent orders */}
        <div className="lg:col-span-2 rounded-2xl border bg-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold">Recent Orders</h2>
            <Link href="/admin/orders" className="text-xs text-brand-green hover:underline flex items-center gap-1">
              View all <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="space-y-3">
            {mockOrders.map(order => (
              <div key={order.id} className="flex items-center justify-between p-3 rounded-xl bg-muted/50">
                <div>
                  <p className="font-medium text-sm">{order.id}</p>
                  <p className="text-xs text-muted-foreground">{new Date(order.createdAt).toLocaleDateString('en-ZA')}</p>
                </div>
                <div className="text-center hidden sm:block">
                  <p className="text-xs text-muted-foreground">{order.items.length} item(s)</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-sm">{formatPrice(order.total)}</p>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                    order.status === 'delivered' ? 'bg-brand-green/10 text-brand-green' :
                    order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>
                    {getOrderStatusLabel(order.status)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Low stock alerts */}
        <div className="rounded-2xl border bg-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-brand-gold" />
              Low Stock Alerts
            </h2>
            <Link href="/admin/inventory" className="text-xs text-brand-green hover:underline">Manage</Link>
          </div>
          <div className="space-y-3">
            {lowStock.map(product => (
              <div key={product.id} className="flex items-center justify-between p-3 rounded-xl bg-muted/50">
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-xs truncate">{product.name}</p>
                  <p className="text-[10px] text-muted-foreground">{product.brand}</p>
                </div>
                <span className={`ml-2 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  product.stock <= 3 ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700'
                }`}>
                  {product.stock} left
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top customers */}
      <div className="mt-6 rounded-2xl border bg-card p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold">Top Customers</h2>
          <Link href="/admin/customers" className="text-xs text-brand-green hover:underline">View all</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground uppercase tracking-wider border-b">
                <th className="text-left pb-2">Customer</th>
                <th className="text-left pb-2">Orders</th>
                <th className="text-right pb-2">Total Spent</th>
                <th className="text-right pb-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {mockCustomers.map(c => (
                <tr key={c.id}>
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-7 w-7 rounded-full bg-brand-green/10 flex items-center justify-center text-xs font-bold text-brand-green">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium">{c.name}</p>
                        <p className="text-xs text-muted-foreground">{c.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3">{c.orders}</td>
                  <td className="py-3 text-right font-medium">{formatPrice(c.totalSpent)}</td>
                  <td className="py-3 text-right">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                      c.status === 'active' ? 'bg-brand-green/10 text-brand-green' : 'bg-muted text-muted-foreground'
                    }`}>
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
