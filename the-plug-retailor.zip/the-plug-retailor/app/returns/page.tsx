export default function ReturnsPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-3xl">
      <h1 className="text-4xl font-bold mb-3">Returns & Refund Policy</h1>
      <p className="text-muted-foreground mb-10">Last updated: November 2024</p>

      <div className="space-y-8 text-sm leading-relaxed text-muted-foreground">
        {[
          {
            title: '1. New Products — 30-Day Return Policy',
            body: `We offer a 30-day return policy for all new products. To be eligible for a return, your item must be unused and in the same condition as when you received it. It must also be in the original packaging.\n\nTo initiate a return, contact us at returns@theplugretailor.co.za with your order number and reason for return. We will provide a prepaid return label where applicable.`,
          },
          {
            title: '2. Preloved Products — 7-Day Return Policy',
            body: `Preloved products are eligible for a return within 7 days of delivery if the item's condition does not match the listing description. Buyers must provide photographic evidence of any discrepancy.\n\nReturns are not accepted for change of mind on preloved items. All preloved items are clearly graded before listing.`,
          },
          {
            title: '3. Non-Returnable Items',
            body: `The following items cannot be returned:\n• Beauty and grooming products that have been opened\n• Underwear and swimwear\n• Digital products and gift cards\n• Items damaged due to misuse`,
          },
          {
            title: '4. Refunds',
            body: `Once your return is received and inspected, we will notify you of the approval or rejection of your refund. If approved, your refund will be processed within 5–7 business days. Refunds are made to the original payment method.`,
          },
          {
            title: '5. Exchanges',
            body: `We replace items if they are defective or damaged. If you need to exchange an item for the same item (different size or colour), email us at exchanges@theplugretailor.co.za.`,
          },
          {
            title: '6. Consumer Protection Act (CPA)',
            body: `All returns and refunds comply with the Consumer Protection Act, 2008 (Act 68 of 2008). You have the right to return goods within 5 business days under the CPA where goods do not meet quality standards.`,
          },
        ].map(section => (
          <div key={section.title}>
            <h2 className="text-lg font-bold text-foreground mb-2">{section.title}</h2>
            <p className="whitespace-pre-line">{section.body}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
