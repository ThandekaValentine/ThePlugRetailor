import Link from 'next/link'
import { Button } from '@/components/ui/button'

const faqs = [
  {
    section: 'About The Plug Retailor',
    items: [
      { q: 'What is The Plug Retailor?', a: 'The Plug Retailor is a South African online marketplace exclusively dedicated to South African brands. We sell both brand-new and preloved products from verified local brands.' },
      { q: 'Do you only sell South African brands?', a: 'Yes. Every single brand and product on our platform is South African. This is non-negotiable — our mission is to support local businesses and promote the incredible products being made right here in Mzansi.' },
      { q: 'What is the difference between "New" and "Preloved"?', a: '"New" products are brand new, unused, and in their original condition. "Preloved" products are second-hand items sold by verified individual sellers. Preloved items are graded: Like New, Excellent, Good, or Fair.' },
    ],
  },
  {
    section: 'Orders & Payment',
    items: [
      { q: 'What payment methods do you accept?', a: 'We accept PayFast (which includes credit/debit cards, instant EFT, and SnapScan), Ozow (instant EFT), manual EFT bank transfer, and direct credit/debit card payments.' },
      { q: 'Is it safe to pay on The Plug Retailor?', a: 'Absolutely. All payments are processed through South Africa\'s most trusted payment gateways — PayFast and Ozow — which are fully encrypted and PCI-DSS compliant.' },
      { q: 'Can I cancel my order?', a: 'Orders can be cancelled within 1 hour of placing them. After that, please see our Returns & Refunds policy.' },
    ],
  },
  {
    section: 'Shipping & Delivery',
    items: [
      { q: 'How long does delivery take?', a: 'Standard delivery takes 3–5 business days. Express delivery is 1–2 business days. We deliver to all 9 provinces in South Africa.' },
      { q: 'Do you offer free delivery?', a: 'Yes! All orders over R750 qualify for free standard delivery. Orders under R750 are charged a flat rate of R99.' },
      { q: 'Do you ship internationally?', a: 'Currently we only deliver within South Africa. We are working on expanding to other African countries.' },
    ],
  },
  {
    section: 'Returns & Preloved',
    items: [
      { q: 'What is your return policy?', a: 'We offer a 30-day return policy on new products. Preloved items are eligible for return within 7 days if the condition does not match the listing description.' },
      { q: 'How are preloved items graded?', a: 'Like New: barely used, no visible wear. Excellent: light use with minimal marks. Good: normal wear visible. Fair: clearly used with visible wear — all disclosed upfront.' },
    ],
  },
]

export default function FAQPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-3xl">
      <h1 className="text-4xl font-bold mb-3">Frequently Asked Questions</h1>
      <p className="text-muted-foreground mb-12">Everything you need to know about shopping on The Plug Retailor.</p>

      <div className="space-y-12">
        {faqs.map(section => (
          <div key={section.section}>
            <h2 className="text-xl font-bold mb-4 pb-2 border-b">{section.section}</h2>
            <div className="space-y-4">
              {section.items.map(item => (
                <details key={item.q} className="group rounded-xl border bg-card">
                  <summary className="flex items-center justify-between cursor-pointer p-4 font-medium text-sm list-none">
                    {item.q}
                    <span className="text-muted-foreground group-open:rotate-45 transition-transform text-xl leading-none">+</span>
                  </summary>
                  <div className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">{item.a}</div>
                </details>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-16 text-center p-8 rounded-2xl bg-muted/50">
        <h3 className="font-bold mb-2">Still have questions?</h3>
        <p className="text-sm text-muted-foreground mb-4">Our team is happy to help.</p>
        <Button asChild><Link href="/contact">Contact Us</Link></Button>
      </div>
    </div>
  )
}
